# plaud-cli

Aplicação de terminal multiplataforma (**Windows, macOS e Linux**) que usa automação **Playwright** em segundo plano (`headless=True`) para sincronizar gravações da sua conta no **Plaud Web (`app.plaud.ai`)** ou processar arquivos de áudio locais usando o **Google Gemini Web (`gemini.google.com`)** — **100% gratuito e sem chave de API paga**.

A saída é salva automaticamente com **transcrição completa diarizada**, **resumo executivo**, **tópicos e decisões**, **plano de ação** e **mapa mental interativo** em Markdown (`.md`) e HTML autônomo (`.html` com Mermaid.js + download em SVG).

---

## 1. Pré-requisitos

Antes de instalar, garanta os itens abaixo no seu computador:

- **Google Chrome** instalado *(recomendado; caso não esteja presente, o Playwright utiliza o Chromium automaticamente)*.
- **Python 3.10 ou superior**:
  - **Windows:** [python.org/downloads](https://www.python.org/downloads/) *(durante a instalação, marque **"Add python.exe to PATH"**)*.
  - **macOS:** `brew install python` ou [python.org/downloads/macos](https://www.python.org/downloads/macos/).
- **FFmpeg** *(opcional, mas recomendado para comprimir automaticamente áudios acima de 25 MB antes do upload)*:
  - **Windows:**
    ```powershell
    winget install Gyan.FFmpeg
    ```
  - **macOS:**
    ```bash
    brew install ffmpeg
    ```
  - **Linux (Debian/Ubuntu):**
    ```bash
    sudo apt install ffmpeg
    ```

---

## Fluxo Rápido: Windows -> Git -> MacBook

Para distribuir e instalar o `plaud-cli` sem precisar configurar ambientes manualmente:

1. **No Windows (Gerar Pacote):**
   - Dê duplo clique em **`empacotar_release.bat`** na raiz do projeto.
   - Isso gera o arquivo **`plaud-cli-release.zip`** limpo (sem `.venv`, `.git` ou caches e já com `instalar_mac.command` em formato Unix `LF` e permissão executável `755`).
   - Envie `plaud-cli-release.zip` para o repositório Git.
2. **No MacBook (Instalar com 1 Duplo Clique):**
   - Baixe **`plaud-cli-release.zip`** do repositório Git.
   - Dê **duplo clique** no `.zip` pelo Finder para descompactar e entre na pasta extraída.
   - Dê **duplo clique** em **`instalar_mac.command`** *(sem precisar abrir terminal para rodar `chmod +x`)*.
   - Ao concluir, abra o **Terminal** e digite **`plaud`**.
3. **No Windows (Instalar na própria máquina ou em outro PC):**
   - Dê duplo clique em **`instalar_windows.bat`**.
   - Abra um novo terminal e digite **`plaud`**.

---

## 2. Instalação Detalhada

### Windows (`instalar_windows.bat`)

1. Baixe ou clone este repositório no seu computador.
2. Dê um **duplo clique** no arquivo **`instalar_windows.bat`** na pasta raiz do projeto.
3. O instalador irá automaticamente:
   - Criar o ambiente virtual `.venv`;
   - Instalar todas as dependências (`pip install -e .`) e o navegador Chromium do Playwright;
   - Criar o atalho global `plaud.cmd` em `%USERPROFILE%\.local\bin` e adicioná-lo ao seu `PATH`.
4. Ao ver a mensagem de conclusão, **feche a janela, abra um novo terminal** (PowerShell, Prompt de Comando ou Windows Terminal) e digite:
   ```powershell
   plaud
   ```

### macOS / MacBook (`instalar_mac.command`)

1. Baixe e descompacte **`plaud-cli-release.zip`** dando duplo clique no Finder *(ou clone este repositório)*.
2. Se você baixou via `plaud-cli-release.zip`, **`instalar_mac.command` já vem com permissão executável (`755`)** — basta dar **duplo clique** nele no Finder.
   > Caso tenha clonado direto via `git clone` (e não pelo `.zip`), rode uma vez `chmod +x instalar_mac.command` antes do duplo clique.
   > Se o macOS avisar sobre desenvolvedor não identificado ao abrir pelo Finder, clique com o botão direito em `instalar_mac.command` → **Abrir**.
3. O script cria a `.venv`, instala as dependências + Chromium do Playwright, cria o link global `/usr/local/bin/plaud` *(pode pedir a senha do Mac caso `/usr/local/bin` precise de `sudo`)* e garante `/usr/local/bin` no `~/.zshrc`.
4. Abra um novo **Terminal** e digite:
   ```bash
   plaud
   ```

<details>
<summary>Instalação manual (Linux / avançado)</summary>

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
playwright install chromium
```

</details>

---

## 3. Primeiro Uso e Configuração de Login

Ao digitar **`plaud`** no terminal sem argumentos, o menu numérico interativo é exibido:

```text
1. Sincronizar e analisar áudios do Plaud Web (app.plaud.ai)
2. Anexar e analisar arquivo de áudio local
3. Configurar / Trocar Login do Google Gemini
4. Configurar / Trocar Login do Plaud Web
5. Sair
```

> **Como funciona o login único:** Os perfis ficam salvos localmente em disco. Você faz login **uma única vez** em uma janela visível do navegador; depois disso, todas as sincronizações e análises rodam silenciosamente em segundo plano (`headless=True`).

Para configurar suas contas na primeira vez:

1. Rode `plaud` no terminal.
2. Digite **`3`** e pressione `Enter` para abrir o **Google Gemini Web (`gemini.google.com/app`)**. Faça login na sua conta Google, volte ao terminal e pressione **`Enter`** para salvar e fechar a janela.
3. Digite **`4`** e pressione `Enter` para abrir o **Plaud Web (`app.plaud.ai`)**. Faça login na sua conta Plaud, volte ao terminal e pressione **`Enter`** para salvar e fechar.

*(Se preferir ir direto via subcomando, você também pode usar `plaud login gemini` e `plaud login plaud`.)*

---

## 4. Uso no Dia a Dia

### Sincronizar gravações do Plaud Web
1. Execute **`plaud`** e escolha a opção **`1`**.
2. O sistema acessa `app.plaud.ai` em segundo plano, lista suas gravações com data, duração e status (`Novo` ou `Já baixado`) — ignorando áudios já registrados em histórico.
3. Digite os números desejados (ex.: `1`, `1,3`, `1-3` ou `todas`) e confirme se deseja analisar imediatamente no Gemini Web.
4. Os áudios baixados ficam salvos em **`Documentos/PlaudCLI/audios`**.

*(Via linha de comando direta: `plaud sync`, `plaud sync --all-new --open` ou `plaud sync --all-new --download-only`.)*

### Anexar e analisar um áudio local
1. Execute **`plaud`** e escolha a opção **`2`**.
2. **Arraste e solte** o arquivo de áudio (`.mp3`, `.wav`, `.opus`, `.ogg`, `.m4a`, `.flac`, `.webm`) diretamente dentro da janela do terminal e pressione `Enter` *(aspas e espaços escapados do Explorer/Finder são limpos automaticamente)*.
3. Opcionalmente informe instruções extras para o Gemini (ex.: *"Foque em prazos e decisões técnicas"*).
4. Áudios maiores que **25 MB** são comprimidos automaticamente em pasta temporária usando `ffmpeg` (sem alterar seu arquivo original).

*(Via linha de comando direta: `plaud analyze --audio "/caminho/do/audio.mp3" --open`.)*

### Onde encontrar os relatórios e mapas mentais gerados

Todos os resultados são gravados automaticamente em:

- **Windows:** `%USERPROFILE%\Documents\PlaudCLI\resultados` *(Documentos/PlaudCLI/resultados)*
- **macOS / Linux:** `~/Documents/PlaudCLI/resultados`

Para cada áudio analisado são gerados dois arquivos:
- **`.md`** — Relatório completo em Markdown (Título, Resumo Executivo, Tópicos e Decisões, Tabela de Action Items, bloco Mermaid `mindmap` e Transcrição Diarizada).
- **`.html`** — Versão visual interativa pronta para abrir em qualquer navegador, com renderização do **Mapa Mental Mermaid.js** e botão para baixar o diagrama em **SVG**.

> **Depuração automática:** Em caso de erro ou timeout durante a automação no Gemini Web, um screenshot e o HTML da página são salvos automaticamente em `~/.plaud_cli/debug_error.png` e `~/.plaud_cli/debug_error.html`.

---

## 5. Comandos Diretos Úteis

```bash
plaud                       # Abre o menu interativo principal
plaud sync --all-new --open # Baixa áudios novos do Plaud, analisa e abre o HTML
plaud analyze --audio x.mp3 # Analisa um áudio local específico
plaud login gemini          # Abre navegador para logar/trocar conta no Gemini
plaud login plaud           # Abre navegador para logar/trocar conta no Plaud Web
plaud config --show         # Mostra as pastas configuradas atualmente
plaud history               # Lista análises registradas no histórico
```

---

## 6. Estrutura do Projeto

```text
plaud-cli/
├── empacotar_release.bat   # Empacota plaud-cli-release.zip com permissões Unix (LF + 755)
├── instalar_windows.bat    # Instalador automático com wrapper global para Windows
├── instalar_mac.command    # Instalador automático com symlink global para macOS
├── pyproject.toml          # Metadados, dependências e entrypoints (plaud / plaud-cli)
├── README.md
├── src/
│   └── plaud_cli/
│       ├── __init__.py
│       ├── main.py         # CLI Typer e Menu Numérico (Rich Prompt/IntPrompt)
│       ├── config.py       # Diretórios nativos via platformdirs
│       ├── browser.py      # Gerenciador Playwright persistente + fluxo híbrido
│       ├── plaud_web.py    # Coleta e download em app.plaud.ai (headless)
│       ├── gemini_web.py   # Upload, prompt e extração em gemini.google.com (headless)
│       ├── audio.py        # Validação e compressão > 25 MB com ffmpeg
│       ├── device.py       # Sanitização de caminhos arrastados e hash SHA-256
│       └── exporter.py     # history.json, .md e .html interativo (Mermaid.js + SVG)
└── tests/                  # Suíte de testes automatizados (pytest)
```
