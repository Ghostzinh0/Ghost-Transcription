"""Testes unitários para plaud_cli.exporter."""

from datetime import datetime
from pathlib import Path

from plaud_cli.exporter import (
    HistoryStore,
    export_analysis,
    extract_mermaid_mindmap,
    sanitize_mermaid_mindmap,
)

SAMPLE_REPORT = """# Alinhamento de Produto Q4

## 1. Resumo Executivo
Definição do escopo da release de dezembro.

## 2. Tópicos Principais e Decisões
- Priorizar fluxo de exportação HTML.

## 3. Plano de Ação / Tarefas (Action Items)
| Tarefa | Responsável | Prazo |
| --- | --- | --- |
| Finalizar CLI | Bruno | Sexta-feira |

## 4. Mapa Mental
```mermaid
mindmap
  root((Alinhamento Q4))
    Escopo
      Exportacao HTML (v1)
      Integracao Gemini: Web
    Prazos
      Release sexta
```

## 5. Transcrição Completa Diarizada
**Locutor 1:** Vamos fechar o escopo hoje.

**Locutor 2:** Combinado!
"""


def test_sanitize_and_extract_mermaid_mindmap() -> None:
    extracted = extract_mermaid_mindmap(SAMPLE_REPORT)
    assert extracted is not None
    assert extracted.startswith("mindmap\n")
    assert "root((Alinhamento Q4))" in extracted
    assert "(v1)" not in extracted
    assert "Exportacao HTML v1" in extracted
    assert "Integracao Gemini - Web" in extracted

    sanitized_empty = sanitize_mermaid_mindmap("")
    assert "root((Mapa Mental))" in sanitized_empty


def test_export_analysis_creates_md_and_standalone_html(tmp_path: Path) -> None:
    audio_path = tmp_path / "Reuniao Produto.mp3"
    audio_path.write_bytes(b"fake")
    out_dir = tmp_path / "resultados"
    fixed_ts = datetime(2026, 11, 12, 18, 30, 0)

    exported = export_analysis(
        SAMPLE_REPORT,
        audio_path=audio_path,
        output_dir=out_dir,
        timestamp=fixed_ts,
    )

    assert exported.md_path.exists()
    assert exported.html_path.exists()
    assert exported.has_mindmap is True
    assert exported.md_path.name == "Reuniao_Produto_20261112_183000.md"
    assert exported.html_path.name == "Reuniao_Produto_20261112_183000.html"

    html_text = exported.html_path.read_text(encoding="utf-8")
    assert "mermaid.esm.min.mjs" in html_text
    assert "download-svg" in html_text
    assert "Alinhamento de Produto Q4" in html_text


def test_history_json_store_downloads_and_analyses(tmp_path: Path) -> None:
    history_path = tmp_path / "history.json"
    store = HistoryStore(history_path=history_path)

    assert store.is_plaud_downloaded("rec-1") is False
    store.record_plaud_download(
        plaud_id="rec-1",
        title="Daily",
        date_label="12/11/2026 09:00",
        duration_label="05:10",
        audio_path=tmp_path / "daily.mp3",
    )
    assert store.is_plaud_downloaded("rec-1") is True
    assert store.get_plaud_download("rec-1") is not None

    assert store.is_processed("hash-abc") is False
    store.record_processed(
        file_hash="hash-abc",
        file_name="daily.mp3",
        source_path=tmp_path / "daily.mp3",
        size_bytes=2048,
        md_path=tmp_path / "daily.md",
        html_path=tmp_path / "daily.html",
        plaud_id="rec-1",
    )
    assert store.is_processed("hash-abc") is True
    records = store.list_records()
    assert len(records) == 1
    assert records[0].plaud_id == "rec-1"
