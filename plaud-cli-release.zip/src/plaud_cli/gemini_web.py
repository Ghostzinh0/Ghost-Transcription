"""Automação Playwright 100% headless no Google Gemini Web (gemini.google.com/app)."""

from __future__ import annotations

import time
from pathlib import Path

from playwright.sync_api import Locator, Page
from playwright.sync_api import Error as PlaywrightError
from rich.console import Console

from plaud_cli.audio import PreparedAudioFile
from plaud_cli.browser import (
    open_authenticated_page,
    save_debug_html,
    save_debug_screenshot,
)

RESPONSE_TIMEOUT_SECONDS = 300.0

GEMINI_STRUCTURED_PROMPT = """Analise integralmente o arquivo de áudio anexo e gere um relatório completo em Português do Brasil, utilizando formatação Markdown limpa e rigorosamente estruturada nas 6 seções abaixo.

Não invente informações que não estejam no áudio. Quando um responsável ou prazo não for citado, escreva "Não especificado".

# <Título Sugerido>

## 1. Resumo Executivo
<Resumo conciso e objetivo capturando o contexto principal e as conclusões da gravação.>

## 2. Tópicos Principais e Decisões
- <Bullet points detalhados dos assuntos discutidos e decisões tomadas>

## 3. Plano de Ação / Tarefas (Action Items)
| Tarefa | Responsável | Prazo |
| --- | --- | --- |
| <Descrição da tarefa> | <Nome ou Não especificado> | <Prazo ou Não especificado> |

*(Se não houver tarefas definidas, inclua uma linha: "Nenhuma tarefa definida | - | -".)*

## 4. Mapa Mental
Gere um bloco de código `mermaid` válido com sintaxe `mindmap`:
- Use exatamente um nó raiz `root((Tema Central))`.
- Use indentação consistente de 2 espaços por nível.
- NÃO utilize parênteses `()`, colchetes `[]`, chaves `{}`, aspas, crases, dois-pontos `:` ou ponto-e-vírgula `;` nos rótulos dos nós filhos para não quebrar o parser.

```mermaid
mindmap
  root((Tema Central))
    Tópico 1
      Subtópico A
      Subtópico B
    Tópico 2
      Subtópico C
```

## 5. Transcrição Completa Diarizada
Transcreva integralmente as falas em ordem cronológica, identificando os interlocutores em negrito no formato:
**Locutor 1:** Fala...

**Locutor 2:** Fala...
"""

_DOM_TO_MARKDOWN_JS = """(root) => {
    if (!root) return '';

    const cleanInline = (el) => {
        if (!el) return '';
        if (el.nodeType === Node.TEXT_NODE) {
            return el.textContent || '';
        }
        if (el.nodeType !== Node.ELEMENT_NODE) return '';
        const tag = el.tagName.toLowerCase();
        if (tag === 'br') return '\\n';
        if (tag === 'strong' || tag === 'b') {
            const inner = Array.from(el.childNodes).map(cleanInline).join('').trim();
            return inner ? `**${inner}**` : '';
        }
        if (tag === 'em' || tag === 'i') {
            const inner = Array.from(el.childNodes).map(cleanInline).join('').trim();
            return inner ? `*${inner}*` : '';
        }
        if (tag === 'code' && !el.closest('pre')) {
            return '`' + (el.textContent || '') + '`';
        }
        return Array.from(el.childNodes).map(cleanInline).join('');
    };

    const serializeTable = (table) => {
        const rows = Array.from(table.querySelectorAll('tr'));
        if (!rows.length) return '';
        const lines = [];
        rows.forEach((tr, rowIdx) => {
            const cells = Array.from(tr.querySelectorAll('th, td')).map(c =>
                cleanInline(c).replace(/\\|/g, '/').replace(/\\s+/g, ' ').trim()
            );
            if (!cells.length) return;
            lines.push('| ' + cells.join(' | ') + ' |');
            if (rowIdx === 0) {
                lines.push('| ' + cells.map(() => '---').join(' | ') + ' |');
            }
        });
        return lines.join('\\n');
    };

    const serializeNode = (node) => {
        if (node.nodeType === Node.TEXT_NODE) {
            const txt = (node.textContent || '').trim();
            return txt ? txt + '\\n\\n' : '';
        }
        if (node.nodeType !== Node.ELEMENT_NODE) return '';
        const tag = node.tagName.toLowerCase();

        if (tag === 'style' || tag === 'script' || tag === 'button') return '';
        if (tag === 'h1' || tag === 'h2' || tag === 'h3' || tag === 'h4') {
            const level = '#'.repeat(parseInt(tag[1], 10));
            return `${level} ${cleanInline(node).trim()}\\n\\n`;
        }
        if (tag === 'p') {
            const text = cleanInline(node).trim();
            return text ? `${text}\\n\\n` : '';
        }
        if (tag === 'ul' || tag === 'ol') {
            const items = Array.from(node.children)
                .filter(c => c.tagName && c.tagName.toLowerCase() === 'li')
                .map((li, idx) => {
                    const prefix = tag === 'ol' ? `${idx + 1}. ` : '- ';
                    return prefix + cleanInline(li).replace(/\\s+/g, ' ').trim();
                });
            return items.length ? items.join('\\n') + '\\n\\n' : '';
        }
        if (tag === 'table') {
            const tbl = serializeTable(node);
            return tbl ? tbl + '\\n\\n' : '';
        }
        if (tag === 'pre' || node.matches('code-block, .code-block')) {
            const codeEl = node.querySelector('code') || node;
            const codeText = (codeEl.textContent || '').trim();
            if (!codeText) return '';
            const cls = (codeEl.className || '') + ' ' + (node.className || '');
            let lang = '';
            const match = cls.match(/language-([a-z0-9_-]+)/i);
            if (match) {
                lang = match[1];
            } else if (/^mindmap\\b/im.test(codeText)) {
                lang = 'mermaid';
            } else {
                const header = node.closest('code-block')?.querySelector('.code-block-decoration, span');
                const hText = (header?.textContent || '').trim().toLowerCase();
                if (hText.includes('mermaid')) lang = 'mermaid';
            }
            return '```' + lang + '\\n' + codeText + '\\n```\\n\\n';
        }
        if (tag === 'blockquote') {
            const text = cleanInline(node).trim().split('\\n').map(l => `> ${l}`).join('\\n');
            return text ? text + '\\n\\n' : '';
        }

        // Container genérico: percorre filhos
        let out = '';
        for (const child of node.childNodes) {
            out += serializeNode(child);
        }
        return out;
    };

    return serializeNode(root).replace(/\\n{3,}/g, '\\n\\n').trim();
}"""


class GeminiWebError(RuntimeError):
    """Erro durante automação no Gemini Web."""

    def __init__(
        self,
        message: str,
        *,
        debug_screenshot: Path | None = None,
        debug_html: Path | None = None,
    ) -> None:
        details: list[str] = [message]
        if debug_screenshot is not None:
            details.append(f"Screenshot de debug salvo em: {debug_screenshot}")
        if debug_html is not None:
            details.append(f"HTML de debug salvo em: {debug_html}")
        super().__init__("\n".join(details))
        self.debug_screenshot = debug_screenshot
        self.debug_html = debug_html


def build_gemini_prompt(user_context: str | None = None) -> str:
    """Constrói o prompt completo somando instruções opcionais do usuário."""
    if user_context and user_context.strip():
        return (
            f"{GEMINI_STRUCTURED_PROMPT.strip()}\n\n"
            f"Instruções adicionais do usuário:\n{user_context.strip()}"
        )
    return GEMINI_STRUCTURED_PROMPT.strip()


_UPLOAD_BTN_SELECTOR = (
    ".upload-icon button, button.upload-card-button, input-area-v2 button:first-of-type"
)

_UPLOAD_MENU_ITEM_SELECTOR = (
    "[role='menuitem']:has-text('arquivo'), "
    "[role='menuitem']:has-text('file'), "
    "[role='menuitem']:has-text('Upload'), "
    "[role='menuitem']:has-text('Enviar')"
)

_UPLOAD_MENU_FALLBACK_SELECTOR = (
    "button:has-text('Enviar arquivo'), "
    "button:has-text('Enviar arquivos'), "
    "button:has-text('Fazer upload'), "
    "button:has-text('Upload file'), "
    "button:has-text('Upload files')"
)

_DISMISS_MODAL_LABELS: tuple[str, ...] = (
    "Aceitar tudo",
    "Accept all",
    "Entendi",
    "Got it",
    "Continuar",
    "Fechar",
)


def _find_first_visible(page: Page, selectors: tuple[str, ...], timeout_ms: int = 3000) -> Locator | None:
    for sel in selectors:
        loc = page.locator(sel).first
        try:
            if loc.is_visible(timeout=timeout_ms):
                return loc
        except Exception:
            continue
    return None


def _dismiss_initial_modals(page: Page) -> None:
    """Aguarda estabilização inicial e dispensa pop-ups de consentimento ou boas-vindas."""
    try:
        page.wait_for_load_state("networkidle", timeout=10000)
    except PlaywrightError:
        pass
    page.wait_for_timeout(800)

    for _ in range(2):
        clicked_any = False
        for label in _DISMISS_MODAL_LABELS:
            for sel in (
                f"button:has-text('{label}')",
                f"[role='button']:has-text('{label}')",
            ):
                loc = page.locator(sel).first
                try:
                    if loc.is_visible(timeout=500):
                        loc.click()
                        page.wait_for_timeout(600)
                        clicked_any = True
                        break
                except Exception:
                    continue
        if not clicked_any:
            break


def _upload_audio_to_gemini(page: Page, audio_path: Path) -> Locator:
    """Localiza '+' relativo à caixa de texto (seletor ou bounding_box), abre menu e envia o áudio."""
    resolved_audio = str(audio_path.resolve())

    # 1. Espera a caixa de texto principal ficar visível
    text_box = page.locator("div[contenteditable='true'], rich-textarea").first
    try:
        text_box.wait_for(state="visible", timeout=30000)
    except PlaywrightError as exc:
        raise GeminiWebError(
            f"Caixa de texto do Gemini Web não ficou visível a tempo: {exc}"
        ) from exc

    # 2. Localiza o botão '+' no container da barra de input ou por coordenadas à esquerda da caixa de texto
    upload_btn = page.locator(_UPLOAD_BTN_SELECTOR).first
    clicked_plus = False
    try:
        upload_btn.wait_for(state="visible", timeout=1500)
        upload_btn.click()
        clicked_plus = True
    except PlaywrightError:
        clicked_plus = False

    if not clicked_plus:
        box = text_box.bounding_box()
        if box is None:
            raise GeminiWebError(
                "Não foi possível obter as coordenadas (bounding_box) da caixa de texto no Gemini Web."
            )
        page.mouse.click(box["x"] - 24, box["y"] + box["height"] / 2)

    # Aguarda 1 segundo para o menu suspenso abrir
    page.wait_for_timeout(1000)

    # 3. Captura o arquivo via menu suspenso (expect_file_chooser) ou fallback direto em input[type='file']
    attached = False
    for menu_sel, wait_ms in (
        (_UPLOAD_MENU_ITEM_SELECTOR, 2000),
        (_UPLOAD_MENU_FALLBACK_SELECTOR, 800),
    ):
        menu_opt = page.locator(menu_sel).first
        try:
            menu_opt.wait_for(state="visible", timeout=wait_ms)
            with page.expect_file_chooser(timeout=10000) as fc_info:
                menu_opt.click()
            fc_info.value.set_files(resolved_audio)
            attached = True
            break
        except PlaywrightError:
            continue

    if not attached:
        file_input = page.locator("input[type='file']").first
        try:
            if file_input.count() > 0:
                file_input.set_input_files(resolved_audio)
                attached = True
        except PlaywrightError as exc:
            raise GeminiWebError(
                f"Falha ao anexar o arquivo '{audio_path.name}' via input[type='file']: {exc}"
            ) from exc

    if not attached:
        raise GeminiWebError(
            f"Não foi possível anexar o arquivo '{audio_path.name}' no Gemini Web."
        )

    _wait_for_attachment_ready(page, audio_path.name)
    return text_box


def _wait_for_attachment_ready(
    page: Page,
    filename: str,
    timeout_seconds: float = 90.0,
    min_wait_seconds: float = 5.0,
) -> None:
    """Aguarda pelo menos 5s para o upload do áudio concluir e sem barra de progresso ativa."""
    started = time.monotonic()
    deadline = started + timeout_seconds
    chip_selectors = (
        "uploader-file-preview",
        "[data-test-id*='file-preview']",
        "[aria-label*='Remover' i]",
        "[aria-label*='Remove' i]",
        f"text={filename}",
    )

    seen_chip = False
    while time.monotonic() < deadline:
        for sel in chip_selectors:
            try:
                if page.locator(sel).first.is_visible(timeout=400):
                    seen_chip = True
                    break
            except Exception:
                continue

        uploading = False
        for prog_sel in (
            "mat-progress-spinner",
            "mat-progress-bar",
            "[role='progressbar']",
        ):
            try:
                if page.locator(prog_sel).first.is_visible(timeout=200):
                    uploading = True
                    break
            except Exception:
                continue

        elapsed = time.monotonic() - started
        if (seen_chip or elapsed >= min_wait_seconds) and not uploading and elapsed >= min_wait_seconds:
            return
        time.sleep(0.6)


def _fill_and_submit_prompt(page: Page, prompt_text: str, text_box: Locator | None = None) -> None:
    """Clica em text_box, preenche o prompt e envia pressionando Enter."""
    editable = page.locator("div[contenteditable='true'], textarea").first
    box = editable if editable.count() > 0 else text_box
    if box is None:
        raise GeminiWebError("Caixa de texto do prompt não encontrada no Gemini Web.")

    box.click()
    box.fill(prompt_text)
    page.wait_for_timeout(300)
    box.press("Enter")


def _is_stop_button_visible(page: Page) -> bool:
    stop_selectors = (
        "button[aria-label*='Parar' i]",
        "button[aria-label*='Stop' i]",
        "button:has(mat-icon[data-mat-icon-name='stop'])",
        "button:has(mat-icon[fonticon='stop'])",
    )
    for sel in stop_selectors:
        try:
            if page.locator(sel).first.is_visible(timeout=300):
                return True
        except Exception:
            continue
    return False


def _extract_last_response_markdown(page: Page) -> str:
    """Extrai o Markdown do último bloco de resposta (`model-response` / `message-content`)."""
    response_selectors = (
        "model-response message-content",
        "message-content",
        "model-response",
        ".model-response-text",
        ".markdown",
    )
    for sel in response_selectors:
        loc = page.locator(sel)
        try:
            count = loc.count()
        except Exception:
            count = 0
        if count > 0:
            last_el = loc.nth(count - 1)
            markdown_text = last_el.evaluate(_DOM_TO_MARKDOWN_JS)
            if isinstance(markdown_text, str) and markdown_text.strip():
                return markdown_text.strip()
            fallback_text = (last_el.inner_text() or "").strip()
            if fallback_text:
                return fallback_text
    return ""


def _wait_for_gemini_response(
    page: Page,
    *,
    previous_response_count: int,
    timeout_seconds: float = RESPONSE_TIMEOUT_SECONDS,
) -> str:
    """Aguarda a resposta completa monitorando o desaparecimento do botão Parar/Stop."""
    deadline = time.monotonic() + timeout_seconds
    generation_started = False

    while time.monotonic() < deadline:
        if _is_stop_button_visible(page):
            generation_started = True
            time.sleep(1.0)
            continue

        current_count = 0
        try:
            current_count = page.locator("model-response, message-content").count()
        except Exception:
            pass

        if generation_started or current_count > previous_response_count:
            # Aguarda um pequeno período de estabilização para evitar corte no final
            page.wait_for_timeout(1200)
            if _is_stop_button_visible(page):
                generation_started = True
                continue
            extracted = _extract_last_response_markdown(page)
            if extracted:
                return extracted

        time.sleep(0.8)

    raise GeminiWebError(
        f"Tempo limite de {timeout_seconds:.0f}s excedido aguardando a resposta do Gemini Web."
    )


def analyze_audio_via_gemini_web(
    prepared_audio: PreparedAudioFile,
    *,
    user_context: str | None = None,
    console: Console | None = None,
    timeout_seconds: float = RESPONSE_TIMEOUT_SECONDS,
) -> str:
    """Envia o áudio e o prompt para gemini.google.com/app em headless=True e retorna o Markdown."""
    prompt_text = build_gemini_prompt(user_context)
    out = console or Console()

    with open_authenticated_page("gemini", console=out) as (_context, page):
        try:
            page_title = ""
            try:
                page_title = page.title()
            except Exception:
                pass
            out.print(
                f"[dim]Gemini carregado: URL={page.url} | Título={page_title}[/dim]"
            )

            _dismiss_initial_modals(page)
            try:
                previous_count = page.locator("model-response, message-content").count()
            except Exception:
                previous_count = 0

            text_box = _upload_audio_to_gemini(page, prepared_audio.upload_path)
            _fill_and_submit_prompt(page, prompt_text, text_box=text_box)
            return _wait_for_gemini_response(
                page,
                previous_response_count=previous_count,
                timeout_seconds=timeout_seconds,
            )
        except GeminiWebError as exc:
            if exc.debug_screenshot is None or exc.debug_html is None:
                shot = save_debug_screenshot(page) if exc.debug_screenshot is None else None
                html_dump = save_debug_html(page) if exc.debug_html is None else None
                raise GeminiWebError(
                    str(exc),
                    debug_screenshot=shot,
                    debug_html=html_dump,
                ) from exc
            raise
        except PlaywrightError as exc:
            shot = save_debug_screenshot(page)
            html_dump = save_debug_html(page)
            raise GeminiWebError(
                f"Falha de automação Playwright no Gemini Web: {exc}",
                debug_screenshot=shot,
                debug_html=html_dump,
            ) from exc
        except Exception as exc:
            shot = save_debug_screenshot(page)
            html_dump = save_debug_html(page)
            raise GeminiWebError(
                f"Erro inesperado ao processar no Gemini Web: {exc}",
                debug_screenshot=shot,
                debug_html=html_dump,
            ) from exc

