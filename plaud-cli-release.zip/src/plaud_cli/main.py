"""Entrypoint CLI (Typer) e Menu Numérico Interativo (Rich Prompt/IntPrompt)."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import IntPrompt, Prompt
from rich.table import Table

from plaud_cli import __version__
from plaud_cli.audio import (
    AudioProcessingError,
    is_ffmpeg_available,
    prepared_audio_file,
)
from plaud_cli.browser import (
    BrowserSessionError,
    interactive_login,
)
from plaud_cli.config import (
    AppConfig,
    get_config_file_path,
    get_debug_screenshot_path,
    get_history_file_path,
    get_profile_dir,
    load_config,
    update_stored_config,
)
from plaud_cli.device import compute_file_hash, sanitize_dragged_path
from plaud_cli.exporter import (
    ExportedFiles,
    HistoryStore,
    export_analysis,
    open_in_browser,
)
from plaud_cli.gemini_web import GeminiWebError, analyze_audio_via_gemini_web
from plaud_cli.plaud_web import (
    PlaudRecording,
    PlaudWebError,
    download_plaud_recordings,
    fetch_plaud_recordings,
)

app = typer.Typer(
    name="plaud",
    help=(
        "CLI multiplataforma (macOS, Windows e Linux) via Playwright para sincronizar "
        "gravações do Plaud Web e gerar resumos, tarefas e mapas mentais via Google Gemini Web."
    ),
    invoke_without_command=True,
    no_args_is_help=False,
)

console = Console()


def _is_interactive_terminal() -> bool:
    return sys.stdin.isatty() and sys.stdout.isatty()


def _render_banner() -> None:
    console.print(
        Panel.fit(
            f"[bold cyan]plaud[/bold cyan] [dim](plaud-cli v{__version__})[/dim]\n"
            "[white]Plaud Web + Google Gemini Web via Playwright (100% sem API paga)[/white]",
            border_style="cyan",
        )
    )


def _prompt_yes_no(question: str, *, default: str = "s") -> bool:
    answer = Prompt.ask(
        question,
        choices=["s", "n"],
        default=default,
        console=console,
    )
    return answer.strip().lower() == "s"


def _prompt_optional_context() -> str | None:
    if not _is_interactive_terminal():
        return None
    text = Prompt.ask(
        "Instruções extras para o Gemini (opcional, Enter para pular)",
        default="",
        console=console,
    )
    cleaned = text.strip()
    return cleaned or None


def _parse_numeric_selection(raw_input: str, total: int) -> list[int]:
    """Converte entrada numérica (ex: '1', '1,3', '1-3', 'novas', 'todas') em índices 0-based."""
    cleaned = raw_input.strip().lower()
    if not cleaned or cleaned in {"0", "sair", "voltar", "cancelar"}:
        return []
    if cleaned in {"todas", "all", "*"}:
        return list(range(total))

    selected: list[int] = []
    seen: set[int] = set()
    for part in cleaned.split(","):
        token = part.strip()
        if not token:
            continue
        if "-" in token:
            bounds = token.split("-", 1)
            if bounds[0].strip().isdigit() and bounds[1].strip().isdigit():
                start = int(bounds[0].strip())
                end = int(bounds[1].strip())
                step = 1 if start <= end else -1
                for num in range(start, end + step, step):
                    if 1 <= num <= total and (num - 1) not in seen:
                        seen.add(num - 1)
                        selected.append(num - 1)
        elif token.isdigit():
            num = int(token)
            if 1 <= num <= total and (num - 1) not in seen:
                seen.add(num - 1)
                selected.append(num - 1)
    return selected


def _render_plaud_table(recordings: list[PlaudRecording]) -> None:
    table = Table(title="Gravações no Plaud Web (app.plaud.ai)", header_style="bold cyan")
    table.add_column("#", style="dim", width=4, justify="right")
    table.add_column("Título / Data", style="bold")
    table.add_column("Duração", width=10, justify="right")
    table.add_column("Histórico", width=16)

    for idx, rec in enumerate(recordings, start=1):
        status = (
            "[green]Já baixado[/green]"
            if rec.already_downloaded
            else "[yellow]Novo[/yellow]"
        )
        title_date = f"{rec.title}\n[dim]{rec.date_label}[/dim]"
        table.add_row(str(idx), title_date, rec.duration_label, status)

    console.print(table)


def _process_audio_with_gemini(
    audio_path: Path,
    *,
    config: AppConfig,
    user_context: str | None = None,
    output_dir_override: Path | None = None,
    open_browser: bool | None = None,
    plaud_id: str | None = None,
    history: HistoryStore | None = None,
) -> ExportedFiles | None:
    """Valida, comprime se > 25 MB (ffmpeg), processa no Gemini Web e exporta .md/.html."""
    target_output_dir = output_dir_override or config.output_dir
    store = history or HistoryStore()

    try:
        with prepared_audio_file(audio_path) as prepared:
            if prepared.ffmpeg_missing_warning:
                console.print(
                    Panel(
                        prepared.ffmpeg_missing_warning,
                        title="[yellow]Aviso ffmpeg[/yellow]",
                        border_style="yellow",
                    )
                )
            elif prepared.was_compressed:
                orig_mb = prepared.original_size_bytes / (1024 * 1024)
                comp_mb = prepared.upload_size_bytes / (1024 * 1024)
                console.print(
                    f"[green]Áudio comprimido via ffmpeg:[/green] "
                    f"{orig_mb:.2f} MB -> {comp_mb:.2f} MB (MP3 mono 64kbps 16kHz; original intacto)."
                )

            with console.status(
                f"[cyan]Enviando '{prepared.original_path.name}' para o Google Gemini Web (headless)...[/cyan]",
                spinner="dots",
            ):
                markdown_report = analyze_audio_via_gemini_web(
                    prepared,
                    user_context=user_context,
                    console=console,
                )

            exported = export_analysis(
                markdown_report,
                audio_path=prepared.original_path,
                output_dir=target_output_dir,
            )

            file_hash = compute_file_hash(prepared.original_path)
            store.record_processed(
                file_hash=file_hash,
                file_name=prepared.original_path.name,
                source_path=prepared.original_path,
                size_bytes=prepared.original_size_bytes,
                md_path=exported.md_path,
                html_path=exported.html_path,
                plaud_id=plaud_id,
            )
    except AudioProcessingError as exc:
        console.print(f"[red]Erro no arquivo de áudio:[/red] {exc}")
        return None
    except (GeminiWebError, BrowserSessionError) as exc:
        console.print(Panel(str(exc), title="[red]Erro no Gemini Web[/red]", border_style="red"))
        return None

    console.print(
        Panel(
            f"[green]Relatório e Mapa Mental gerados com sucesso![/green]\n\n"
            f"• [bold]Markdown:[/bold] {exported.md_path}\n"
            f"• [bold]HTML + Mapa Mental:[/bold] {exported.html_path}",
            title=f"[cyan]{audio_path.name}[/cyan]",
            border_style="green",
        )
    )

    should_open = open_browser
    if should_open is None and _is_interactive_terminal():
        should_open = _prompt_yes_no(
            "Deseja abrir o relatório HTML com o Mapa Mental no navegador agora?",
            default="s",
        )

    if should_open:
        if not open_in_browser(exported.html_path):
            console.print(
                f"[yellow]Abra manualmente no navegador:[/yellow] {exported.html_path}"
            )

    return exported


def _run_plaud_sync_flow(
    *,
    config: AppConfig,
    all_new: bool = False,
    analyze_after: bool = True,
    context: str | None = None,
    output_dir: Path | None = None,
    open_browser: bool | None = None,
) -> None:
    """Sincroniza gravações do Plaud Web, baixa para ~/Documents/PlaudCLI/audios e analisa."""
    history = HistoryStore()
    try:
        with console.status(
            "[cyan]Conectando ao Plaud Web (app.plaud.ai) em segundo plano...[/cyan]",
            spinner="dots",
        ):
            recordings = fetch_plaud_recordings(console=console, history=history)
    except (PlaudWebError, BrowserSessionError) as exc:
        console.print(Panel(str(exc), title="[red]Erro no Plaud Web[/red]", border_style="red"))
        return

    _render_plaud_table(recordings)

    if all_new:
        selected = [rec for rec in recordings if not rec.already_downloaded]
        if not selected:
            console.print("[green]Todas as gravações já constam no histórico local (history.json).[/green]")
            return
    else:
        if not _is_interactive_terminal():
            console.print("Use `--all-new` para baixar todas as gravações novas em modo não interativo.")
            return

        console.print(
            "[dim]Digite os números separados por vírgula (ex: 1,2), 'novas', 'todas' ou '0' para cancelar.[/dim]"
        )
        raw_choice = Prompt.ask("Quais gravações deseja baixar", default="novas")
        if raw_choice.strip().lower() == "novas":
            selected = [rec for rec in recordings if not rec.already_downloaded]
            if not selected:
                console.print("[green]Nenhuma gravação nova encontrada no Plaud Web.[/green]")
                return
        else:
            indices = _parse_numeric_selection(raw_choice, len(recordings))
            if not indices:
                console.print("[dim]Operação cancelada.[/dim]")
                return
            selected = [recordings[i] for i in indices]

    try:
        with console.status(
            f"[cyan]Baixando {len(selected)} gravação(ões) para {config.audios_dir}...[/cyan]",
            spinner="dots",
        ):
            audio_paths = download_plaud_recordings(
                selected,
                audios_dir=config.audios_dir,
                console=console,
                history=history,
            )
    except (PlaudWebError, BrowserSessionError) as exc:
        console.print(Panel(str(exc), title="[red]Erro ao baixar do Plaud Web[/red]", border_style="red"))
        return

    for p in audio_paths:
        console.print(f"[green]Áudio disponível em:[/green] {p}")

    if not analyze_after:
        return

    if not audio_paths:
        return

    extra_context = context if context is not None else _prompt_optional_context()
    last_exported: ExportedFiles | None = None

    for idx, (rec, local_audio) in enumerate(zip(selected, audio_paths), start=1):
        console.rule(f"[bold cyan]({idx}/{len(audio_paths)}) {local_audio.name}[/bold cyan]")
        exported = _process_audio_with_gemini(
            local_audio,
            config=config,
            user_context=extra_context,
            output_dir_override=output_dir,
            open_browser=open_browser if len(audio_paths) == 1 else False,
            plaud_id=rec.plaud_id,
            history=history,
        )
        if exported is not None:
            last_exported = exported

    if len(audio_paths) > 1 and last_exported is not None:
        should_open = open_browser
        if should_open is None and _is_interactive_terminal():
            should_open = _prompt_yes_no(
                "Processamento em lote concluído! Abrir o último relatório HTML no navegador?",
                default="s",
            )
        if should_open:
            open_in_browser(last_exported.html_path)


def _login_service_interactive(service: str) -> None:
    """Abre janela visível para configurar ou trocar a conta do serviço informado."""
    try:
        profile_path = interactive_login(service, console=console)
        console.print(f"[green]Sessão salva em:[/green] {profile_path}")
    except BrowserSessionError as exc:
        console.print(f"[red]Erro ao abrir navegador:[/red] {exc}")


def _interactive_menu() -> None:
    """Menu numérico principal (1-5) usando exclusivamente rich.prompt."""
    _render_banner()

    while True:
        config = load_config()
        ffmpeg_status = (
            "[green]OK[/green]" if is_ffmpeg_available() else "[yellow]não instalado[/yellow]"
        )
        console.print(
            f"\n[dim]Áudios:[/dim] {config.audios_dir} | "
            f"[dim]Resultados:[/dim] {config.output_dir} | "
            f"[dim]ffmpeg:[/dim] {ffmpeg_status}"
        )
        console.print(
            "\n[bold cyan]Menu Principal[/bold cyan]\n"
            "  [bold]1.[/bold] Sincronizar e analisar áudios do Plaud Web (app.plaud.ai)\n"
            "  [bold]2.[/bold] Anexar e analisar arquivo de áudio local\n"
            "  [bold]3.[/bold] Configurar / Trocar Login do Google Gemini\n"
            "  [bold]4.[/bold] Configurar / Trocar Login do Plaud Web\n"
            "  [bold]5.[/bold] Sair"
        )
        choice = IntPrompt.ask(
            "Selecione uma opção",
            choices=["1", "2", "3", "4", "5"],
            default=1,
            console=console,
        )

        if choice == 5:
            console.print("[dim]Até logo![/dim]")
            return

        if choice == 1:
            _run_plaud_sync_flow(config=config, analyze_after=True)
        elif choice == 2:
            raw_path = Prompt.ask(
                "Arraste o arquivo de áudio ou digite o caminho completo (Enter para cancelar)",
                default="",
                console=console,
            )
            if not raw_path.strip():
                continue
            audio_path = sanitize_dragged_path(raw_path)
            user_context = _prompt_optional_context()
            _process_audio_with_gemini(
                audio_path,
                config=config,
                user_context=user_context,
            )
        elif choice == 3:
            _login_service_interactive("gemini")
        elif choice == 4:
            _login_service_interactive("plaud")


@app.callback(invoke_without_command=True)
def main_callback(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        "-v",
        help="Exibe a versão do plaud-cli e encerra.",
        is_eager=True,
    ),
) -> None:
    """Executa o menu numérico interativo quando nenhum subcomando é informado."""
    if version:
        console.print(f"plaud-cli {__version__}")
        raise typer.Exit()
    if ctx.invoked_subcommand is None:
        if not _is_interactive_terminal():
            console.print(ctx.get_help())
            raise typer.Exit()
        try:
            _interactive_menu()
        except KeyboardInterrupt:
            console.print("\n[dim]Operação cancelada pelo usuário.[/dim]")
            raise typer.Exit(code=130)


@app.command()
def login(
    service: str = typer.Argument(
        ...,
        help="Serviço para autenticar em janela visível: 'gemini' ou 'plaud'.",
    ),
) -> None:
    """Abre janela visível para logar ou trocar conta no Gemini Web ou Plaud Web."""
    normalized = service.strip().lower()
    if normalized not in {"gemini", "plaud"}:
        console.print("[red]Serviço inválido. Use:[/red] `plaud-cli login gemini` ou `plaud-cli login plaud`.")
        raise typer.Exit(code=1)

    try:
        profile_dir = interactive_login(normalized, console=console)
        console.print(f"[green]Login salvo com sucesso no perfil:[/green] {profile_dir}")
    except BrowserSessionError as exc:
        console.print(f"[red]Erro ao iniciar login:[/red] {exc}")
        raise typer.Exit(code=1)


@app.command()
def analyze(
    audio: str = typer.Option(
        ...,
        "--audio",
        "-a",
        help="Caminho para o arquivo de áudio (.mp3, .wav, .opus, .ogg, .m4a, .flac, .webm).",
    ),
    context: Optional[str] = typer.Option(
        None,
        "--context",
        "-c",
        help="Instruções extras opcionais enviadas ao Gemini Web junto com o áudio.",
    ),
    output_dir: Optional[Path] = typer.Option(
        None,
        "--output-dir",
        "-o",
        help="Pasta para salvar os relatórios .md e .html.",
    ),
    open_browser: Optional[bool] = typer.Option(
        None,
        "--open/--no-open",
        help="Abre o HTML do mapa mental automaticamente no navegador.",
    ),
) -> None:
    """Analisa um arquivo de áudio local via Google Gemini Web (headless)."""
    config = load_config()
    audio_path = sanitize_dragged_path(audio)
    extra_context = context
    if extra_context is None and _is_interactive_terminal():
        extra_context = _prompt_optional_context()

    result = _process_audio_with_gemini(
        audio_path,
        config=config,
        user_context=extra_context,
        output_dir_override=output_dir,
        open_browser=open_browser,
    )
    if result is None:
        raise typer.Exit(code=1)


@app.command()
def sync(
    all_new: bool = typer.Option(
        False,
        "--all-new",
        help="Baixa automaticamente todas as gravações ainda não presentes no history.json.",
    ),
    download_only: bool = typer.Option(
        False,
        "--download-only",
        help="Apenas baixa os áudios do Plaud Web sem enviá-los ao Gemini Web.",
    ),
    context: Optional[str] = typer.Option(
        None,
        "--context",
        "-c",
        help="Instruções extras opcionais para a análise no Gemini Web.",
    ),
    output_dir: Optional[Path] = typer.Option(
        None,
        "--output-dir",
        "-o",
        help="Pasta para salvar os relatórios .md e .html.",
    ),
    open_browser: Optional[bool] = typer.Option(
        None,
        "--open/--no-open",
        help="Abre o HTML gerado no navegador ao finalizar.",
    ),
) -> None:
    """Sincroniza gravações recentes do Plaud Web (app.plaud.ai) em segundo plano."""
    config = load_config()
    _run_plaud_sync_flow(
        config=config,
        all_new=all_new,
        analyze_after=not download_only,
        context=context,
        output_dir=output_dir,
        open_browser=open_browser,
    )


@app.command()
def config(
    set_audios: Optional[str] = typer.Option(
        None,
        "--set-audios",
        help="Define a pasta onde os áudios do Plaud Web serão salvos.",
    ),
    set_output: Optional[str] = typer.Option(
        None,
        "--set-output",
        help="Define a pasta de saída dos relatórios .md e .html.",
    ),
    show: bool = typer.Option(
        False,
        "--show",
        help="Exibe diretórios configurados e caminhos dos perfis Playwright.",
    ),
) -> None:
    """Configura e exibe os diretórios nativos do plaud-cli."""
    has_updates = set_audios is not None or set_output is not None
    if has_updates:
        cfg_file = update_stored_config(
            audios_dir=sanitize_dragged_path(set_audios) if set_audios else None,
            output_dir=sanitize_dragged_path(set_output) if set_output else None,
        )
        console.print(f"[green]Configuração salva em:[/green] {cfg_file}")

    if show or not has_updates:
        effective = load_config()
        table = Table(title="Configuração Efetiva — plaud-cli", header_style="bold cyan")
        table.add_column("Parâmetro", style="bold")
        table.add_column("Caminho / Status", overflow="fold")
        table.add_row("Pasta de áudios", str(effective.audios_dir))
        table.add_row("Pasta de resultados", str(effective.output_dir))
        table.add_row("Perfil Playwright Gemini", str(get_profile_dir("gemini")))
        table.add_row("Perfil Playwright Plaud", str(get_profile_dir("plaud")))
        table.add_row("Histórico local", str(get_history_file_path()))
        table.add_row("Screenshot de debug", str(get_debug_screenshot_path()))
        table.add_row("Arquivo config.json", str(get_config_file_path()))
        table.add_row(
            "ffmpeg",
            is_ffmpeg_available() or "[yellow]não encontrado no PATH[/yellow]",
        )
        console.print(table)


@app.command()
def history(
    limit: int = typer.Option(
        20,
        "--limit",
        "-n",
        min=1,
        max=200,
        help="Quantidade máxima de registros exibidos.",
    ),
) -> None:
    """Exibe o histórico local de análises registradas em history.json."""
    store = HistoryStore()
    records = store.list_records(limit=limit)
    if not records:
        console.print("[dim]Nenhuma análise registrada em history.json ainda.[/dim]")
        return

    table = Table(title="Histórico de Análises (history.json)", header_style="bold cyan")
    table.add_column("Data", width=19)
    table.add_column("Arquivo", style="bold")
    table.add_column("Markdown / HTML")

    for rec in records:
        table.add_row(
            rec.processed_at.replace("T", " "),
            rec.file_name,
            f"{rec.md_path}\n[dim]{rec.html_path}[/dim]",
        )
    console.print(table)


if __name__ == "__main__":
    app()
