"""Testes unitários para browser.py, plaud_web.py e gemini_web.py."""

from contextlib import contextmanager
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from plaud_cli.browser import (
    get_realistic_user_agent,
    launch_persistent_browser,
    open_authenticated_page,
)
from plaud_cli.exporter import HistoryStore
from plaud_cli.gemini_web import build_gemini_prompt
from plaud_cli.plaud_web import download_plaud_recordings, parse_plaud_api_payload


def test_user_agent_per_os() -> None:
    assert "Macintosh" in get_realistic_user_agent("Darwin")
    assert "Windows" in get_realistic_user_agent("Windows")
    assert "Linux" in get_realistic_user_agent("Linux")


def test_launch_persistent_browser_chrome_fallback_to_chromium(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from playwright.sync_api import Error as PlaywrightError

    monkeypatch.setattr("plaud_cli.browser.find_profile_lock_pids", lambda _p: [])

    calls: list[dict] = []
    fake_ctx = MagicMock()

    def fake_launch(**kwargs):
        calls.append(kwargs)
        if kwargs.get("channel") == "chrome":
            raise PlaywrightError("Chrome not installed")
        return fake_ctx

    pw = MagicMock()
    pw.chromium.launch_persistent_context.side_effect = fake_launch

    ctx = launch_persistent_browser(pw, tmp_path / "prof", headless=True)
    assert ctx is fake_ctx
    assert len(calls) == 2
    assert calls[0]["channel"] == "chrome"
    assert calls[0]["headless"] is True
    assert calls[0]["viewport"] == {"width": 1920, "height": 1080}
    assert "--disable-blink-features=AutomationControlled" in calls[0]["args"]
    assert "channel" not in calls[1]


def test_open_authenticated_page_hybrid_login_flow(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    headless_states: list[bool] = []
    login_attempts = 0
    wait_called = False

    def fake_launch(_pw, _prof, *, headless: bool, downloads_path=None):
        headless_states.append(headless)
        ctx = MagicMock()
        page = MagicMock()
        ctx.pages = [page]
        return ctx

    def fake_needs_login(_page) -> bool:
        nonlocal login_attempts
        login_attempts += 1
        # Primeira tentativa headless exige login; após login visível, segunda headless passa
        return login_attempts == 1

    def fake_wait() -> None:
        nonlocal wait_called
        wait_called = True

    @contextmanager
    def fake_sync_pw():
        yield MagicMock()

    monkeypatch.setattr("plaud_cli.browser.sync_playwright", fake_sync_pw)
    monkeypatch.setattr("plaud_cli.browser.launch_persistent_browser", fake_launch)
    monkeypatch.setattr("plaud_cli.browser.is_gemini_login_required", fake_needs_login)

    with open_authenticated_page(
        "gemini",
        profile_dir=tmp_path / "gemini_prof",
        wait_for_login_fn=fake_wait,
    ) as (_ctx, _page):
        pass

    assert wait_called is True
    assert headless_states == [True, False, True]


def test_parse_plaud_api_payload_and_skip_downloaded(tmp_path: Path) -> None:
    payload = {
        "data_file_list": [
            {
                "id": "abc123",
                "filename": "Reuniao Semanal",
                "start_time": 1731400000000,
                "duration": 125000,
                "download_url": "https://cdn.plaud.ai/abc123.mp3",
            }
        ]
    }
    recordings = parse_plaud_api_payload(payload)
    assert len(recordings) == 1
    assert recordings[0].plaud_id == "abc123"
    assert recordings[0].duration_label == "02:05"

    # Se já registrado em history.json e arquivo existe, não abre navegador novamente
    history = HistoryStore(history_path=tmp_path / "history.json")
    local_audio = tmp_path / "audios" / "Reuniao_Semanal_abc123.mp3"
    local_audio.parent.mkdir(parents=True)
    local_audio.write_bytes(b"mp3-bytes")
    history.record_plaud_download(
        plaud_id="abc123",
        title="Reuniao Semanal",
        date_label="12/11/2026",
        duration_label="02:05",
        audio_path=local_audio,
    )

    paths = download_plaud_recordings(
        recordings,
        audios_dir=local_audio.parent,
        history=history,
    )
    assert paths == [local_audio]


def test_build_gemini_prompt_includes_required_sections_and_context() -> None:
    prompt = build_gemini_prompt("Foque em prazos do time de vendas.")
    assert "Título Sugerido" in prompt
    assert "Resumo Executivo" in prompt
    assert "Plano de Ação" in prompt
    assert "```mermaid" in prompt
    assert "**Locutor 1:**" in prompt
    assert "Foque em prazos do time de vendas." in prompt


def test_gemini_upload_dismiss_modals_and_file_chooser_with_real_playwright(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from playwright.sync_api import sync_playwright
    from plaud_cli.gemini_web import (
        _dismiss_initial_modals,
        _fill_and_submit_prompt,
        _upload_audio_to_gemini,
    )

    audio_file = tmp_path / "teste.mp3"
    audio_file.write_bytes(b"ID3-audio")

    gemini_mock_html = """
    <html>
      <body>
        <aside>
          <button onclick="window.__sidebarClicked = true">+ Novo notebook</button>
        </aside>
        <div id="modal">
          <button onclick="document.getElementById('modal').remove()">Aceitar tudo</button>
        </div>
        <input-area-v2>
          <button id="plus-btn" class="upload-card-button" onclick="document.getElementById('menu').style.display='block'">
            <mat-icon>add</mat-icon>
          </button>
          <rich-textarea>
            <div contenteditable="true" role="textbox" onkeydown="if (event.key === 'Enter') { event.preventDefault(); window.__sent = true; }"></div>
          </rich-textarea>
        </input-area-v2>
        <div id="menu" style="display:none">
          <button id="upload-opt" role="menuitem" onclick="document.getElementById('file-inp').click()">Enviar arquivos</button>
        </div>
        <input id="file-inp" type="file" style="display:none" onchange="
          const chip = document.createElement('uploader-file-preview');
          chip.textContent = this.files[0].name;
          document.body.appendChild(chip);
        " />
      </body>
    </html>
    """

    # Acelera espera mínima de 5s apenas para o teste unitário
    monkeypatch.setattr(
        "plaud_cli.gemini_web._wait_for_attachment_ready",
        lambda page, fname, **kw: page.locator("uploader-file-preview").wait_for(state="visible", timeout=5000),
    )

    with sync_playwright() as pw:
        ctx = launch_persistent_browser(pw, tmp_path / "prof", headless=True)
        try:
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            page.set_content(gemini_mock_html)
            _dismiss_initial_modals(page)
            assert page.locator("#modal").count() == 0

            text_box = _upload_audio_to_gemini(page, audio_file)
            assert page.locator("uploader-file-preview").inner_text() == "teste.mp3"
            assert page.evaluate("() => window.__sidebarClicked === true") is False

            _fill_and_submit_prompt(page, "Resuma o áudio", text_box=text_box)
            assert page.evaluate("() => window.__sent === true") is True
        finally:
            ctx.close()


def test_gemini_fallback_mounts_input_from_left_button_and_debug_saves_html(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from playwright.sync_api import sync_playwright
    from rich.console import Console
    from plaud_cli.audio import PreparedAudioFile
    from plaud_cli.gemini_web import (
        GeminiWebError,
        _upload_audio_to_gemini,
        analyze_audio_via_gemini_web,
    )

    audio_file = tmp_path / "fallback.mp3"
    audio_file.write_bytes(b"ID3-audio")

    # Sem seletor conhecido no botão '+': apenas coordenadas (box["x"] - 24, box["y"] + box["height"]/2)
    dynamic_html = """
    <html>
      <head><title>Google Gemini</title></head>
      <body style="margin:0;">
        <aside style="position:fixed; left:10px; top:10px;">
          <button onclick="window.__sidebarClicked = true">+ Novo notebook</button>
        </aside>
        <div style="display:flex; align-items:center; width:800px; margin-left:300px; margin-top:400px;">
          <div id="left-attach-btn" style="width:40px; height:40px; cursor:pointer;" onclick="
            const inp = document.createElement('input');
            inp.type = 'file';
            inp.style.display = 'none';
            inp.onchange = function() {
              const chip = document.createElement('uploader-file-preview');
              chip.textContent = this.files[0].name;
              document.body.appendChild(chip);
            };
            document.body.appendChild(inp);
          ">+</div>
          <div contenteditable="true" style="width:600px; height:40px; border:1px solid #ccc;"></div>
        </div>
      </body>
    </html>
    """

    monkeypatch.setattr(
        "plaud_cli.gemini_web._wait_for_attachment_ready",
        lambda page, fname, **kw: page.locator("uploader-file-preview").wait_for(state="visible", timeout=5000),
    )

    with sync_playwright() as pw:
        ctx = launch_persistent_browser(pw, tmp_path / "prof2", headless=True)
        try:
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            page.set_content(dynamic_html)
            _upload_audio_to_gemini(page, audio_file)
            assert page.locator("uploader-file-preview").inner_text() == "fallback.mp3"

            # Verifica salvamento de debug_error.png e debug_error.html + impressão de URL/Title
            monkeypatch.setattr(Path, "home", lambda: tmp_path)

            @contextmanager
            def fake_open_auth(_service, **_kw):
                page.set_content("<html><head><title>Gemini Debug Title</title></head><body><p>no inputs</p></body></html>")
                yield ctx, page

            monkeypatch.setattr("plaud_cli.gemini_web.open_authenticated_page", fake_open_auth)
            monkeypatch.setattr("plaud_cli.gemini_web._dismiss_initial_modals", lambda _p: None)

            captured = Console(record=True)
            prepared = PreparedAudioFile(
                original_path=audio_file,
                upload_path=audio_file,
                was_compressed=False,
                original_size_bytes=audio_file.stat().st_size,
                upload_size_bytes=audio_file.stat().st_size,
            )
            with pytest.raises(GeminiWebError) as exc_info:
                analyze_audio_via_gemini_web(prepared, console=captured)

            output_text = captured.export_text()
            assert "Gemini carregado:" in output_text
            assert "Gemini Debug Title" in output_text
            assert (tmp_path / ".plaud_cli" / "debug_error.png").exists()
            assert (tmp_path / ".plaud_cli" / "debug_error.html").exists()
            assert "debug_error.html" in str(exc_info.value)
        finally:
            ctx.close()


