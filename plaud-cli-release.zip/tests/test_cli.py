"""Testes de integração da CLI (Typer CliRunner) sem dependência de questionary."""

from pathlib import Path

import pytest
from typer.testing import CliRunner

from plaud_cli.exporter import HistoryStore
from plaud_cli.main import _parse_numeric_selection, app
from plaud_cli.plaud_web import PlaudRecording

runner = CliRunner()


def test_cli_version_and_no_questionary() -> None:
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "plaud-cli" in result.stdout


def test_parse_numeric_selection() -> None:
    assert _parse_numeric_selection("1,3", 5) == [0, 2]
    assert _parse_numeric_selection("2-4", 5) == [1, 2, 3]
    assert _parse_numeric_selection("todas", 3) == [0, 1, 2]
    assert _parse_numeric_selection("0", 3) == []


def test_cli_config_set_and_show(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    cfg_dir = tmp_path / "cfg"
    data_dir = tmp_path / "data"
    monkeypatch.setattr("plaud_cli.config.get_config_dir", lambda: cfg_dir)
    monkeypatch.setattr("plaud_cli.config.get_data_dir", lambda: data_dir)
    monkeypatch.setattr("plaud_cli.main.get_config_file_path", lambda: cfg_dir / "config.json")
    monkeypatch.setattr("plaud_cli.main.get_history_file_path", lambda: data_dir / "history.json")
    monkeypatch.setattr(
        "plaud_cli.main.get_profile_dir",
        lambda svc: data_dir / "profiles" / svc,
    )

    audios_dir = tmp_path / "audios"
    out_dir = tmp_path / "resultados"
    res = runner.invoke(
        app,
        [
            "config",
            "--set-audios",
            str(audios_dir),
            "--set-output",
            str(out_dir),
            "--show",
        ],
    )
    assert res.exit_code == 0
    assert "Pasta de áudios" in res.stdout
    assert "Pasta de resultados" in res.stdout
    from plaud_cli.config import load_config
    effective = load_config(config_dir=cfg_dir)
    assert effective.audios_dir == audios_dir
    assert effective.output_dir == out_dir


def test_cli_login_command(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    called: list[str] = []

    def fake_login(service: str, **_kwargs):
        called.append(service)
        return tmp_path / "profiles" / service

    monkeypatch.setattr("plaud_cli.main.interactive_login", fake_login)

    res_gemini = runner.invoke(app, ["login", "gemini"])
    res_plaud = runner.invoke(app, ["login", "plaud"])
    assert res_gemini.exit_code == 0
    assert res_plaud.exit_code == 0
    assert called == ["gemini", "plaud"]


def test_cli_analyze_end_to_end_mocked(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    audio_file = tmp_path / "demo.mp3"
    audio_file.write_bytes(b"ID3-fake-mp3-data")
    out_dir = tmp_path / "resultados"
    history_file = tmp_path / "history.json"

    monkeypatch.setattr("plaud_cli.main._is_interactive_terminal", lambda: False)
    monkeypatch.setattr("plaud_cli.main.HistoryStore", lambda: HistoryStore(history_path=history_file))
    monkeypatch.setattr(
        "plaud_cli.main.analyze_audio_via_gemini_web",
        lambda prepared, **_kwargs: (
            "# Reunião Teste\n\n## 4. Mapa Mental\n```mermaid\nmindmap\n  root((Teste))\n    Item A\n```\n"
        ),
    )

    res = runner.invoke(
        app,
        [
            "analyze",
            "--audio",
            str(audio_file),
            "--output-dir",
            str(out_dir),
            "--no-open",
        ],
    )
    assert res.exit_code == 0
    md_files = list(out_dir.glob("demo_*.md"))
    html_files = list(out_dir.glob("demo_*.html"))
    assert len(md_files) == 1
    assert len(html_files) == 1
    assert "Reunião Teste" in md_files[0].read_text(encoding="utf-8")


def test_cli_sync_all_new_mocked(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    audios_dir = tmp_path / "audios"
    out_dir = tmp_path / "resultados"
    history_file = tmp_path / "history.json"
    store = HistoryStore(history_path=history_file)

    monkeypatch.setattr("plaud_cli.main._is_interactive_terminal", lambda: False)
    monkeypatch.setattr("plaud_cli.main.HistoryStore", lambda: store)

    recs = [
        PlaudRecording(
            plaud_id="p1",
            title="Sync Meeting",
            date_label="12/11/2026 10:00",
            duration_label="03:20",
            already_downloaded=False,
        )
    ]
    monkeypatch.setattr("plaud_cli.main.fetch_plaud_recordings", lambda **_kw: recs)

    downloaded_audio = audios_dir / "Sync_Meeting_p1.mp3"

    def fake_download(selected, *, audios_dir: Path, **_kw):
        downloaded_audio.parent.mkdir(parents=True, exist_ok=True)
        downloaded_audio.write_bytes(b"fake-audio-bytes")
        return [downloaded_audio]

    monkeypatch.setattr("plaud_cli.main.download_plaud_recordings", fake_download)
    monkeypatch.setattr(
        "plaud_cli.main.analyze_audio_via_gemini_web",
        lambda _p, **_kw: "# Sync OK\n\n## 4. Mapa Mental\n```mermaid\nmindmap\n  root((Sync))\n    Ok\n```\n",
    )

    res = runner.invoke(
        app,
        ["sync", "--all-new", "--output-dir", str(out_dir), "--no-open"],
    )
    assert res.exit_code == 0
    assert len(list(out_dir.glob("Sync_Meeting_p1_*.md"))) == 1
    assert len(list(out_dir.glob("Sync_Meeting_p1_*.html"))) == 1


def test_cli_interactive_menu_5_options(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    called_logins: list[str] = []

    def fake_login(service: str, **_kwargs):
        called_logins.append(service)
        return tmp_path / "profiles" / service

    monkeypatch.setattr("plaud_cli.main._is_interactive_terminal", lambda: True)
    monkeypatch.setattr("plaud_cli.main.interactive_login", fake_login)

    # Opção 3 (Gemini), depois 4 (Plaud), depois 5 (Sair)
    res = runner.invoke(app, [], input="3\n4\n5\n")
    assert res.exit_code == 0
    assert "Sincronizar e analisar áudios do Plaud Web" in res.stdout
    assert "Configurar / Trocar Login do Google Gemini" in res.stdout
    assert "Configurar / Trocar Login do Plaud Web" in res.stdout
    assert called_logins == ["gemini", "plaud"]

