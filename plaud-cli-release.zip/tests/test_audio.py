"""Testes unitários para plaud_cli.audio."""

from pathlib import Path

import pytest

from plaud_cli.audio import (
    MAX_AUDIO_BYTES,
    AudioProcessingError,
    prepared_audio_file,
    validate_audio_file,
)


def test_max_audio_threshold_is_25_mb() -> None:
    assert MAX_AUDIO_BYTES == 25 * 1024 * 1024


def test_validate_audio_file_errors(tmp_path: Path) -> None:
    with pytest.raises(AudioProcessingError, match="não encontrado"):
        validate_audio_file(tmp_path / "missing.mp3")

    txt_file = tmp_path / "doc.txt"
    txt_file.write_text("abc", encoding="utf-8")
    with pytest.raises(AudioProcessingError, match="não suportado"):
        validate_audio_file(txt_file)

    empty_mp3 = tmp_path / "empty.mp3"
    empty_mp3.write_bytes(b"")
    with pytest.raises(AudioProcessingError, match="vazio"):
        validate_audio_file(empty_mp3)


def test_prepared_audio_file_under_limit_skips_ffmpeg(tmp_path: Path) -> None:
    audio_file = tmp_path / "sample.opus"
    audio_file.write_bytes(b"OggS-fake-opus-payload")

    with prepared_audio_file(audio_file, max_bytes=1024) as prepared:
        assert prepared.was_compressed is False
        assert prepared.upload_path == audio_file
        assert prepared.ffmpeg_missing_warning is None


def test_prepared_audio_file_over_limit_without_ffmpeg_warns(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    audio_file = tmp_path / "large.wav"
    audio_file.write_bytes(b"0" * 2048)

    monkeypatch.setattr("plaud_cli.audio.is_ffmpeg_available", lambda: None)

    with prepared_audio_file(audio_file, max_bytes=1024) as prepared:
        assert prepared.was_compressed is False
        assert prepared.upload_path == audio_file
        assert prepared.ffmpeg_missing_warning is not None
        assert "25 MB" in prepared.ffmpeg_missing_warning


def test_prepared_audio_file_over_limit_compresses_in_temp_dir(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    audio_file = tmp_path / "large.wav"
    audio_file.write_bytes(b"R" * 4096)

    monkeypatch.setattr("plaud_cli.audio.is_ffmpeg_available", lambda: "/usr/bin/ffmpeg")

    def fake_compress(source_path: Path, target_path: Path, *, ffmpeg_bin: str | None = None) -> Path:
        assert source_path == audio_file
        assert ffmpeg_bin == "/usr/bin/ffmpeg"
        target_path.write_bytes(b"MP3COMPRESSED")
        return target_path

    monkeypatch.setattr("plaud_cli.audio.compress_audio_to_mp3", fake_compress)

    with prepared_audio_file(audio_file, max_bytes=1024) as prepared:
        assert prepared.was_compressed is True
        assert prepared.upload_path != audio_file
        assert prepared.upload_path.exists()
        assert prepared.upload_size_bytes == len(b"MP3COMPRESSED")
        temp_upload = prepared.upload_path

    assert not temp_upload.exists()
