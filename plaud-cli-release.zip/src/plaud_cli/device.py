"""Detecção multiplataforma do Plaud Note Pro / drives externos e varredura de áudios."""

from __future__ import annotations

import ctypes
import getpass
import hashlib
import os
import platform
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable

import psutil

SUPPORTED_AUDIO_EXTENSIONS: frozenset[str] = frozenset(
    {".mp3", ".wav", ".opus", ".ogg", ".m4a", ".flac", ".webm"}
)

PLAUD_FOLDER_HINTS: tuple[str, ...] = (
    "PLAUD",
    "RECORD",
    "RECORDINGS",
    "VOICE",
    "AUDIO",
    "REC",
)

PLAUD_NAME_HINTS: tuple[str, ...] = ("PLAUD", "NOTE", "RECORDER", "VOICE")

IGNORED_DIR_NAMES: frozenset[str] = frozenset(
    {
        ".Spotlight-V100",
        ".Trashes",
        ".fseventsd",
        ".TemporaryItems",
        "System Volume Information",
        "$RECYCLE.BIN",
        "__MACOSX",
    }
)

MACOS_SYSTEM_VOLUMES: frozenset[str] = frozenset(
    {
        "Macintosh HD",
        "Macintosh HD - Data",
        "Recovery",
        "Preboot",
        "VM",
        "Update",
        "com.apple.TimeMachine.localsnapshots",
    }
)

DRIVE_REMOVABLE = 2
_POSIX_ESCAPE_RE = re.compile(r"\\([ \t()\[\]{}'\"&;!$#@,~])")
_WINDOWS_DRIVE_RE = re.compile(r"^[A-Za-z]:[\\/]")


@dataclass(frozen=True)
class DetectedDevice:
    """Representa um volume externo ou pasta de gravações detectada."""

    name: str
    root: Path
    scan_paths: tuple[Path, ...]
    is_plaud_likely: bool
    kind: str  # "usb", "volume", "local"


@dataclass(frozen=True)
class AudioFileInfo:
    """Metadados de um arquivo de áudio encontrado."""

    path: Path
    name: str
    modified_at: datetime
    size_bytes: int
    size_mb: float
    file_hash: str
    processed: bool = False


def sanitize_dragged_path(raw_input: str) -> Path:
    """Limpa caminhos arrastados para o terminal (aspas, prefixo '& ' e escapes)."""
    cleaned = raw_input.strip()
    if not cleaned:
        return Path("")

    # PowerShell ao arrastar arquivo frequentemente prefixa com `& '...'` ou `& "..."`
    if cleaned.startswith("& ") and len(cleaned) > 3:
        candidate = cleaned[2:].strip()
        if (candidate.startswith("'") and candidate.endswith("'")) or (
            candidate.startswith('"') and candidate.endswith('"')
        ):
            cleaned = candidate

    # Remove aspas simples ou duplas envolvendo todo o caminho
    if len(cleaned) >= 2 and (
        (cleaned[0] == '"' and cleaned[-1] == '"')
        or (cleaned[0] == "'" and cleaned[-1] == "'")
    ):
        cleaned = cleaned[1:-1]

    # Trata escapes típicos de macOS/Linux (ex: reuniao\ 01.mp3 -> reuniao 01.mp3)
    # evitando alterar separadores de diretório do Windows (C:\Users\...).
    is_windows_style = bool(_WINDOWS_DRIVE_RE.match(cleaned)) or cleaned.startswith("\\\\")
    if not is_windows_style:
        cleaned = _POSIX_ESCAPE_RE.sub(r"\1", cleaned)
    elif "\\ " in cleaned:
        # Caso raro de caminho híbrido (Git Bash/WSL) com `\ ` antes de espaço
        candidate_unescaped = cleaned.replace("\\ ", " ")
        if not Path(cleaned).exists() and Path(candidate_unescaped).exists():
            cleaned = candidate_unescaped

    return Path(cleaned).expanduser()


def compute_file_hash(file_path: Path, chunk_size: int = 1024 * 1024) -> str:
    """Calcula SHA-256 do arquivo de áudio em streaming."""
    digest = hashlib.sha256()
    with file_path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def _find_recording_dirs(root: Path) -> tuple[tuple[Path, ...], bool]:
    """Procura subpastas típicas de gravação dentro de um volume."""
    matched_dirs: list[Path] = []
    if not root.exists() or not root.is_dir():
        return (), False

    try:
        entries = list(root.iterdir())
    except OSError:
        return (), False

    hints_upper = set(PLAUD_FOLDER_HINTS)
    for entry in entries:
        if entry.name.startswith(".") or entry.name in IGNORED_DIR_NAMES:
            continue
        if entry.is_dir() and entry.name.upper() in hints_upper:
            matched_dirs.append(entry)

    is_plaud = bool(matched_dirs) or any(
        hint in root.name.upper() for hint in PLAUD_NAME_HINTS
    )
    scan_paths = tuple(matched_dirs) if matched_dirs else (root,)
    return scan_paths, is_plaud


def _detect_macos_devices(volumes_root: Path = Path("/Volumes")) -> list[DetectedDevice]:
    """Varre /Volumes/ no macOS por unidades externas recém-montadas."""
    devices: list[DetectedDevice] = []
    if not volumes_root.exists():
        return devices

    try:
        entries = sorted(volumes_root.iterdir(), key=lambda p: p.name.lower())
    except OSError:
        return devices

    for entry in entries:
        if entry.name.startswith(".") or entry.name in MACOS_SYSTEM_VOLUMES:
            continue
        try:
            if entry.is_symlink() and entry.resolve() == Path("/"):
                continue
        except OSError:
            continue
        if not entry.is_dir():
            continue

        scan_paths, is_plaud = _find_recording_dirs(entry)
        if scan_paths:
            devices.append(
                DetectedDevice(
                    name=entry.name,
                    root=entry,
                    scan_paths=scan_paths,
                    is_plaud_likely=is_plaud,
                    kind="volume",
                )
            )
    return devices


def _get_windows_removable_roots() -> list[Path]:
    """Obtém letras de unidades removíveis no Windows via ctypes e psutil."""
    roots: dict[str, Path] = {}

    # 1) ctypes GetLogicalDrives + GetDriveTypeW
    if hasattr(ctypes, "windll"):
        try:
            kernel32 = ctypes.windll.kernel32
            bitmask = kernel32.GetLogicalDrives()
            for idx in range(26):
                if bitmask & (1 << idx):
                    letter = chr(ord("A") + idx)
                    drive_str = f"{letter}:\\"
                    drive_type = kernel32.GetDriveTypeW(drive_str)
                    if drive_type == DRIVE_REMOVABLE:
                        roots[drive_str.upper()] = Path(drive_str)
        except Exception:
            pass

    # 2) psutil como complemento (captura dispositivos MTP/USB montados como disco)
    try:
        for part in psutil.disk_partitions(all=False):
            opts = part.opts.lower()
            mount = part.mountpoint
            if not mount or mount.upper().startswith("C:\\"):
                continue
            if "removable" in opts:
                roots[mount.upper()] = Path(mount)
    except Exception:
        pass

    return [roots[key] for key in sorted(roots)]


def _detect_windows_devices() -> list[DetectedDevice]:
    """Detecta unidades removíveis no Windows e busca pastas de gravação."""
    devices: list[DetectedDevice] = []
    for root in _get_windows_removable_roots():
        if not root.exists():
            continue
        scan_paths, is_plaud = _find_recording_dirs(root)
        if scan_paths:
            devices.append(
                DetectedDevice(
                    name=f"Unidade ({root})",
                    root=root,
                    scan_paths=scan_paths,
                    is_plaud_likely=is_plaud,
                    kind="usb",
                )
            )
    return devices


def _detect_linux_devices(
    *,
    user: str | None = None,
    media_bases: tuple[Path, ...] | None = None,
) -> list[DetectedDevice]:
    """Varre /media/$USER/, /run/media/$USER/ e /mnt/ no Linux."""
    current_user = user or os.environ.get("USER") or getpass.getuser()
    if media_bases is None:
        media_bases = (
            Path("/media") / current_user,
            Path("/run/media") / current_user,
            Path("/mnt"),
        )

    devices: list[DetectedDevice] = []
    seen_roots: set[Path] = set()

    for base in media_bases:
        if not base.exists() or not base.is_dir():
            continue
        try:
            entries = sorted(base.iterdir(), key=lambda p: p.name.lower())
        except OSError:
            continue

        for entry in entries:
            if entry.name.startswith(".") or not entry.is_dir():
                continue
            try:
                resolved = entry.resolve()
            except OSError:
                resolved = entry
            if resolved in seen_roots:
                continue
            seen_roots.add(resolved)

            scan_paths, is_plaud = _find_recording_dirs(entry)
            if scan_paths:
                devices.append(
                    DetectedDevice(
                        name=entry.name,
                        root=entry,
                        scan_paths=scan_paths,
                        is_plaud_likely=is_plaud,
                        kind="volume",
                    )
                )
    return devices


def detect_external_devices(
    extra_sync_dir: Path | None = None,
    *,
    system_name: str | None = None,
) -> list[DetectedDevice]:
    """Detecta unidades externas conectadas e opcionalmente inclui pasta local configurada."""
    current_os = system_name or platform.system()
    devices: list[DetectedDevice] = []

    if current_os == "Darwin":
        devices.extend(_detect_macos_devices())
    elif current_os == "Windows":
        devices.extend(_detect_windows_devices())
    elif current_os == "Linux":
        devices.extend(_detect_linux_devices())

    if extra_sync_dir is not None:
        resolved_extra = extra_sync_dir.expanduser()
        if resolved_extra.exists() and resolved_extra.is_dir():
            scan_paths, is_plaud = _find_recording_dirs(resolved_extra)
            devices.append(
                DetectedDevice(
                    name=f"Pasta configurada ({resolved_extra.name or resolved_extra})",
                    root=resolved_extra,
                    scan_paths=scan_paths or (resolved_extra,),
                    is_plaud_likely=is_plaud,
                    kind="local",
                )
            )

    # Prioriza dispositivos que possuem pastas típicas do Plaud
    devices.sort(key=lambda d: (not d.is_plaud_likely, d.kind == "local", d.name.lower()))
    return devices


def scan_audio_files(
    search_roots: list[Path] | tuple[Path, ...],
    *,
    is_processed_fn: Callable[[str], bool] | None = None,
    recursive: bool = True,
) -> list[AudioFileInfo]:
    """Lista arquivos de áudio suportados ordenados por data de modificação (mais recente primeiro)."""
    found: dict[Path, AudioFileInfo] = {}

    for root in search_roots:
        expanded = root.expanduser()
        if not expanded.exists():
            continue

        if expanded.is_file():
            candidates = [expanded]
        elif recursive:
            candidates = _iter_audio_files_recursive(expanded)
        else:
            candidates = [
                p
                for p in expanded.iterdir()
                if p.is_file() and p.suffix.lower() in SUPPORTED_AUDIO_EXTENSIONS
            ]

        for audio_path in candidates:
            if audio_path.suffix.lower() not in SUPPORTED_AUDIO_EXTENSIONS:
                continue
            try:
                resolved = audio_path.resolve()
                stat = resolved.stat()
            except OSError:
                continue

            if resolved in found or stat.st_size == 0:
                continue

            try:
                file_hash = compute_file_hash(resolved)
            except OSError:
                continue

            processed = bool(is_processed_fn(file_hash)) if is_processed_fn else False
            found[resolved] = AudioFileInfo(
                path=resolved,
                name=resolved.name,
                modified_at=datetime.fromtimestamp(stat.st_mtime),
                size_bytes=stat.st_size,
                size_mb=round(stat.st_size / (1024 * 1024), 2),
                file_hash=file_hash,
                processed=processed,
            )

    return sorted(found.values(), key=lambda item: item.modified_at, reverse=True)


def _iter_audio_files_recursive(root: Path) -> list[Path]:
    """Percorre diretórios ignorando pastas de sistema e arquivos ocultos."""
    results: list[Path] = []
    for current_dir, dirnames, filenames in os.walk(root):
        dirnames[:] = [
            d
            for d in dirnames
            if not d.startswith(".") and d not in IGNORED_DIR_NAMES
        ]
        current_path = Path(current_dir)
        for fname in filenames:
            if fname.startswith("."):
                continue
            candidate = current_path / fname
            if candidate.suffix.lower() in SUPPORTED_AUDIO_EXTENSIONS:
                results.append(candidate)
    return results

