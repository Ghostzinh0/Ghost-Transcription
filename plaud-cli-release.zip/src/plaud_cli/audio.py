"""Validação e compressão inteligente opcional via ffmpeg para envio ao Gemini Web."""

from __future__ import annotations

import platform
import shutil
import subprocess
import tempfile
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

from plaud_cli.device import SUPPORTED_AUDIO_EXTENSIONS

MAX_AUDIO_BYTES = 25 * 1024 * 1024  # 25 MB


class AudioProcessingError(RuntimeError):
    """Erro genérico ao validar ou comprimir arquivo de áudio."""


@dataclass(frozen=True)
class PreparedAudioFile:
    """Representa o arquivo de áudio pronto para upload no navegador."""

    original_path: Path
    upload_path: Path
    was_compressed: bool
    original_size_bytes: int
    upload_size_bytes: int
    ffmpeg_missing_warning: str | None = None


def is_ffmpeg_available() -> str | None:
    """Retorna o caminho do executável ffmpeg se disponível no PATH."""
    return shutil.which("ffmpeg")


def get_ffmpeg_install_instructions(system_name: str | None = None) -> str:
    """Retorna instruções de instalação do ffmpeg para macOS, Windows e Linux."""
    current_os = system_name or platform.system()
    lines = [
        "Instale o ffmpeg para comprimir automaticamente áudios maiores que 25 MB:",
        "  • macOS:   brew install ffmpeg",
        "  • Windows: winget install ffmpeg",
        "  • Linux:   sudo apt install ffmpeg",
    ]
    if current_os == "Darwin":
        lines[1] = "  • macOS:   brew install ffmpeg  (recomendado neste sistema)"
    elif current_os == "Windows":
        lines[2] = "  • Windows: winget install ffmpeg  (recomendado neste sistema)"
    elif current_os == "Linux":
        lines[3] = "  • Linux:   sudo apt install ffmpeg  (recomendado neste sistema)"
    return "\n".join(lines)


def validate_audio_file(audio_path: Path) -> Path:
    """Valida existência, extensão suportada e tamanho não-nulo do áudio."""
    resolved = audio_path.expanduser()
    if not resolved.exists():
        raise AudioProcessingError(f"Arquivo de áudio não encontrado: {resolved}")
    if not resolved.is_file():
        raise AudioProcessingError(f"O caminho informado não é um arquivo: {resolved}")

    suffix = resolved.suffix.lower()
    if suffix not in SUPPORTED_AUDIO_EXTENSIONS:
        supported = ", ".join(sorted(SUPPORTED_AUDIO_EXTENSIONS))
        raise AudioProcessingError(
            f"Formato '{suffix or '(sem extensão)'}' não suportado. "
            f"Formatos aceitos: {supported}"
        )

    if resolved.stat().st_size == 0:
        raise AudioProcessingError(f"O arquivo de áudio está vazio (0 bytes): {resolved}")

    return resolved


def compress_audio_to_mp3(
    source_path: Path,
    target_path: Path,
    *,
    ffmpeg_bin: str | None = None,
) -> Path:
    """Comprime áudio para MP3 mono 64kbps 16kHz usando ffmpeg sem alterar o original."""
    executable = ffmpeg_bin or is_ffmpeg_available()
    if not executable:
        raise AudioProcessingError(
            "ffmpeg não encontrado no sistema.\n" + get_ffmpeg_install_instructions()
        )

    cmd = [
        executable,
        "-y",
        "-i",
        str(source_path),
        "-vn",
        "-ac",
        "1",
        "-ar",
        "16000",
        "-b:a",
        "64k",
        "-f",
        "mp3",
        str(target_path),
    ]

    try:
        completed = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError as exc:
        raise AudioProcessingError(f"Falha ao executar ffmpeg: {exc}") from exc

    if completed.returncode != 0:
        stderr_tail = (completed.stderr or "").strip().splitlines()[-5:]
        detail = "\n".join(stderr_tail) if stderr_tail else "erro desconhecido"
        raise AudioProcessingError(
            f"ffmpeg falhou ao comprimir '{source_path.name}' (código {completed.returncode}):\n{detail}"
        )

    if not target_path.exists() or target_path.stat().st_size == 0:
        raise AudioProcessingError(
            f"ffmpeg concluiu sem gerar um arquivo válido em {target_path}"
        )

    return target_path


@contextmanager
def prepared_audio_file(
    audio_path: Path,
    *,
    max_bytes: int = MAX_AUDIO_BYTES,
) -> Iterator[PreparedAudioFile]:
    """Context manager que valida e comprime (> 25 MB com ffmpeg) em pasta temporária."""
    validated = validate_audio_file(audio_path)
    original_size = validated.stat().st_size

    if original_size <= max_bytes:
        yield PreparedAudioFile(
            original_path=validated,
            upload_path=validated,
            was_compressed=False,
            original_size_bytes=original_size,
            upload_size_bytes=original_size,
        )
        return

    ffmpeg_bin = is_ffmpeg_available()
    if not ffmpeg_bin:
        size_mb = original_size / (1024 * 1024)
        warning = (
            f"O arquivo '{validated.name}' possui {size_mb:.2f} MB (> 25 MB) e o ffmpeg "
            "não foi encontrado para compressão automática. Tentando enviar o arquivo original.\n"
            + get_ffmpeg_install_instructions()
        )
        yield PreparedAudioFile(
            original_path=validated,
            upload_path=validated,
            was_compressed=False,
            original_size_bytes=original_size,
            upload_size_bytes=original_size,
            ffmpeg_missing_warning=warning,
        )
        return

    with tempfile.TemporaryDirectory(prefix="plaud_cli_") as tmp_dir:
        tmp_mp3 = Path(tmp_dir) / f"{validated.stem}_compressed.mp3"
        compress_audio_to_mp3(validated, tmp_mp3, ffmpeg_bin=ffmpeg_bin)
        compressed_size = tmp_mp3.stat().st_size
        yield PreparedAudioFile(
            original_path=validated,
            upload_path=tmp_mp3,
            was_compressed=True,
            original_size_bytes=original_size,
            upload_size_bytes=compressed_size,
        )
