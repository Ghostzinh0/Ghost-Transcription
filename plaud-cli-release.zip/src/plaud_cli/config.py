"""Gerenciamento de diretórios nativos via platformdirs e configurações do plaud-cli."""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path

from platformdirs import (
    user_cache_dir,
    user_config_dir,
    user_data_dir,
    user_documents_path,
)

from plaud_cli import APP_NAME

CONFIG_FILENAME = "config.json"
HISTORY_FILENAME = "history.json"


class ConfigError(RuntimeError):
    """Erro relacionado ao carregamento ou persistência de configuração."""


def get_config_dir() -> Path:
    """Retorna o diretório nativo de configuração do usuário via platformdirs."""
    return Path(user_config_dir(APP_NAME, appauthor=False))


def get_data_dir() -> Path:
    """Retorna o diretório nativo de dados persistentes via platformdirs."""
    return Path(user_data_dir(APP_NAME, appauthor=False))


def get_cache_dir() -> Path:
    """Retorna o diretório nativo de cache via platformdirs."""
    return Path(user_cache_dir(APP_NAME, appauthor=False))


def get_profiles_dir() -> Path:
    """Retorna o diretório raiz para perfis persistentes do navegador via platformdirs."""
    path = get_data_dir() / "profiles"
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_profile_dir(service: str) -> Path:
    """Retorna o diretório do perfil persistente para 'gemini' ou 'plaud'."""
    normalized = service.strip().lower()
    if normalized not in {"gemini", "plaud"}:
        raise ConfigError(f"Serviço de perfil desconhecido: {service}")
    path = get_profiles_dir() / normalized
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_debug_screenshot_path() -> Path:
    """Retorna o caminho padrão ~/.plaud_cli/debug_error.png para screenshots de erro."""
    path = Path.home() / ".plaud_cli" / "debug_error.png"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def get_debug_html_path() -> Path:
    """Retorna o caminho padrão ~/.plaud_cli/debug_error.html para dump HTML de erro."""
    path = Path.home() / ".plaud_cli" / "debug_error.html"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def get_default_base_dir() -> Path:
    """Retorna o diretório base padrão ~/Documents/PlaudCLI."""
    try:
        docs_path = user_documents_path()
        if docs_path:
            return Path(docs_path) / "PlaudCLI"
    except Exception:
        pass
    return Path.home() / "Documents" / "PlaudCLI"


def get_default_audios_dir() -> Path:
    """Retorna a pasta padrão de áudios baixados (~/Documents/PlaudCLI/audios)."""
    return get_default_base_dir() / "audios"


def get_default_output_dir() -> Path:
    """Retorna a pasta padrão de relatórios gerados (~/Documents/PlaudCLI/resultados)."""
    return get_default_base_dir() / "resultados"


def get_history_file_path(data_dir: Path | None = None) -> Path:
    """Retorna o caminho do arquivo history.json."""
    base = data_dir if data_dir is not None else get_data_dir()
    base.mkdir(parents=True, exist_ok=True)
    return base / HISTORY_FILENAME


def get_config_file_path(config_dir: Path | None = None) -> Path:
    """Retorna o caminho completo do arquivo config.json."""
    base = config_dir if config_dir is not None else get_config_dir()
    return base / CONFIG_FILENAME


@dataclass
class AppConfig:
    """Configuração efetiva da aplicação."""

    audios_dir: Path
    output_dir: Path
    sync_dir: Path | None = None


@dataclass
class StoredConfig:
    """Representação serializável salva no config.json."""

    audios_dir: str | None = None
    output_dir: str | None = None
    sync_dir: str | None = None


def _read_stored_config(config_file: Path) -> StoredConfig:
    if not config_file.exists():
        return StoredConfig()
    try:
        raw = json.loads(config_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ConfigError(f"Não foi possível ler {config_file}: {exc}") from exc

    if not isinstance(raw, dict):
        return StoredConfig()

    return StoredConfig(
        audios_dir=raw.get("audios_dir") or None,
        output_dir=raw.get("output_dir") or None,
        sync_dir=raw.get("sync_dir") or None,
    )


def _write_stored_config(config_file: Path, stored: StoredConfig) -> None:
    config_file.parent.mkdir(parents=True, exist_ok=True)
    payload = {k: v for k, v in asdict(stored).items() if v is not None}
    config_file.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def load_config(*, config_dir: Path | None = None) -> AppConfig:
    """Carrega configurações combinando variáveis de ambiente, config.json e padrões."""
    config_file = get_config_file_path(config_dir)
    stored = _read_stored_config(config_file)

    raw_audios = (
        os.environ.get("PLAUD_CLI_AUDIOS_DIR", "").strip()
        or (stored.audios_dir or "").strip()
    )
    audios_dir = (
        Path(raw_audios).expanduser() if raw_audios else get_default_audios_dir()
    )

    raw_output = (
        os.environ.get("PLAUD_CLI_OUTPUT_DIR", "").strip()
        or (stored.output_dir or "").strip()
    )
    output_dir = (
        Path(raw_output).expanduser() if raw_output else get_default_output_dir()
    )

    raw_sync = (
        os.environ.get("PLAUD_CLI_SYNC_DIR", "").strip()
        or (stored.sync_dir or "").strip()
    )
    sync_dir = Path(raw_sync).expanduser() if raw_sync else None

    return AppConfig(
        audios_dir=audios_dir,
        output_dir=output_dir,
        sync_dir=sync_dir,
    )


def update_stored_config(
    *,
    audios_dir: Path | None = None,
    output_dir: Path | None = None,
    sync_dir: Path | None = None,
    clear_sync_dir: bool = False,
    config_dir: Path | None = None,
) -> Path:
    """Atualiza campos específicos no config.json persistente."""
    config_file = get_config_file_path(config_dir)
    stored = _read_stored_config(config_file)

    if audios_dir is not None:
        stored.audios_dir = str(audios_dir.expanduser())
    if output_dir is not None:
        stored.output_dir = str(output_dir.expanduser())
    if sync_dir is not None:
        stored.sync_dir = str(sync_dir.expanduser())
    elif clear_sync_dir:
        stored.sync_dir = None

    _write_stored_config(config_file, stored)
    return config_file
