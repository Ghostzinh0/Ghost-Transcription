@echo off
chcp 65001 >nul
setlocal EnableExtensions

cd /d "%~dp0"

echo ==================================================
echo   Empacotador de Release - plaud-cli (Windows)
echo ==================================================
echo.

set "PY_CMD=python"
where python >nul 2>&1
if errorlevel 1 (
    if exist ".venv\Scripts\python.exe" (
        set "PY_CMD=.venv\Scripts\python.exe"
    ) else (
        echo [ERRO] Python nao encontrado no PATH nem em .venv\Scripts\python.exe.
        echo Instale o Python 3.10+ em https://www.python.org/downloads/ e tente novamente.
        echo.
        pause
        exit /b 1
    )
)

if exist "plaud-cli-release.zip" (
    echo Removendo pacote anterior: plaud-cli-release.zip
    del /f /q "plaud-cli-release.zip"
    if errorlevel 1 (
        echo [ERRO] Nao foi possivel remover o plaud-cli-release.zip anterior.
        pause
        exit /b 1
    )
)

echo Gerando plaud-cli-release.zip...
echo.

"%PY_CMD%" -c "import pathlib, sys; m = '#' + '__PYTHON_START__'; exec(pathlib.Path(sys.argv[1]).read_text(encoding='utf-8').split(m, 1)[1])" "%~f0"
if errorlevel 1 (
    echo.
    echo [ERRO] Falha ao gerar plaud-cli-release.zip.
    pause
    exit /b 1
)

echo.
echo ==================================================
echo   Proximo passo:
echo   Envie o arquivo plaud-cli-release.zip para o
echo   repositorio Git para baixar no MacBook ou outro PC.
echo ==================================================
echo.
pause
exit /b 0

#__PYTHON_START__
import fnmatch
import os
import re
import sys
import time
import zipfile
from pathlib import Path

ZIP_NAME = "plaud-cli-release.zip"

EXCLUDED_DIRS = {
    ".venv",
    "venv",
    ".git",
    ".github",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".idea",
    ".vscode",
    "dist",
    "build",
    ".eggs",
    "htmlcov",
    "profiles",
    "resultados_plaud",
    "audios",
}

EXCLUDED_DIR_PATTERNS = ("*.egg-info",)

EXCLUDED_FILES = {
    ".env",
    "history.json",
    ".coverage",
    ".DS_Store",
    "Thumbs.db",
    ZIP_NAME,
}

ALLOWED_EXACT_FILES = {
    ".env.example",
}

EXCLUDED_FILE_PATTERNS = (
    ".env.*",
    "debug_error.*",
    "*.key",
    "*.pem",
    "*.log",
    "*.mp3",
    "*.wav",
    "*.opus",
    "*.ogg",
    "*.m4a",
    "*.flac",
    "*.webm",
    "*.zip",
    "*.pyc",
    "*.pyo",
    "*.pyd",
)

UNIX_SCRIPT_EXTS = {".command", ".sh"}


def is_excluded_dir(dirname: str) -> bool:
    if dirname in EXCLUDED_DIRS:
        return True
    return any(fnmatch.fnmatch(dirname, pat) for pat in EXCLUDED_DIR_PATTERNS)


def is_excluded_file(filename: str) -> bool:
    if filename in ALLOWED_EXACT_FILES:
        return False
    if filename in EXCLUDED_FILES:
        return True
    return any(fnmatch.fnmatch(filename, pat) for pat in EXCLUDED_FILE_PATTERNS)


total_files = 0
unix_scripts = 0

with zipfile.ZipFile(ZIP_NAME, "w", compression=zipfile.ZIP_DEFLATED) as zf:
    for root, dirnames, filenames in os.walk("."):
        dirnames[:] = sorted(d for d in dirnames if not is_excluded_dir(d))

        for filename in sorted(filenames):
            if is_excluded_file(filename):
                continue

            full_path = Path(root) / filename
            rel_path = os.path.relpath(full_path, ".")
            arcname = rel_path.replace("\\", "/")

            if full_path.suffix.lower() in UNIX_SCRIPT_EXTS:
                raw_bytes = full_path.read_bytes().replace(b"\r\n", b"\n")
                info = zipfile.ZipInfo(arcname)
                mtime = time.localtime(full_path.stat().st_mtime)
                info.date_time = mtime[:6]
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                info.external_attr = 0o755 << 16
                zf.writestr(info, raw_bytes)
                unix_scripts += 1
                print(f"  [UNIX 755 LF] {arcname}")
            else:
                zf.write(full_path, arcname=arcname)

            total_files += 1

# Auditoria de seguranca no conteudo textual empacotado no ZIP
secret_openrouter = "sk-or-" + "v1-"
secret_google = "AIza" + "Sy"
local_win_user_re = re.compile(
    r"C:" + r"\\Us" + r"ers\\[A-Za-z0-9_-]+",
    re.IGNORECASE,
)

security_hits: list[str] = []
with zipfile.ZipFile(ZIP_NAME, "r") as zf:
    for entry in zf.infolist():
        if entry.is_dir():
            continue
        raw = zf.read(entry.filename)
        if b"\x00" in raw:
            continue
        text = raw.decode("utf-8", errors="ignore")
        if secret_openrouter in text:
            security_hits.append(f"{entry.filename}: chave OpenRouter detectada ({secret_openrouter}...)")
        if secret_google in text:
            security_hits.append(f"{entry.filename}: chave Google detectada ({secret_google}...)")
        if local_win_user_re.search(text):
            security_hits.append(f"{entry.filename}: caminho local de usuario Windows detectado")

if security_hits:
    Path(ZIP_NAME).unlink(missing_ok=True)
    print("")
    print("[ERRO DE SEGURANCA] Dados sensiveis ou caminhos locais detectados no pacote:")
    for hit in security_hits:
        print(f"  - {hit}")
    print("Pacote abortado e removido por seguranca.")
    sys.exit(1)

zip_size_bytes = Path(ZIP_NAME).stat().st_size
zip_size_kb = zip_size_bytes / 1024
zip_size_mb = zip_size_kb / 1024
print("")
print("Auditoria de seguranca concluida: nenhum segredo ou caminho pessoal encontrado.")
print(f"Pacote criado com sucesso: {ZIP_NAME}")
print(f"Arquivos empacotados: {total_files} ({unix_scripts} script(s) Unix executavel(is))")
print(f"Tamanho final: {zip_size_kb:.1f} KB ({zip_size_mb:.2f} MB)")
