"""Exportação em Markdown e HTML autônomo com Mermaid.js + histórico local em history.json."""

from __future__ import annotations

import html
import json
import re
import webbrowser
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import markdown as md_lib

from plaud_cli.config import get_history_file_path

_MERMAID_BLOCK_RE = re.compile(
    r"```mermaid\s*\r?\n(.*?)\r?\n```",
    re.DOTALL | re.IGNORECASE,
)
_ROOT_NODE_RE = re.compile(r"^(\s*root)\(\((.*)\)\)\s*$")
_UNSAFE_FILENAME_RE = re.compile(r"[^\w\-]+", re.UNICODE)

MERMAID_PLACEHOLDER = "<!-- PLAUD_CLI_MERMAID_CARD -->"


@dataclass(frozen=True)
class HistoryRecord:
    """Registro de áudio já analisado salvo em history.json."""

    file_hash: str
    file_name: str
    source_path: str
    size_bytes: int
    processed_at: str
    md_path: str
    html_path: str
    plaud_id: str | None = None


@dataclass(frozen=True)
class DownloadedPlaudRecord:
    """Registro de gravação do Plaud Web já baixada."""

    plaud_id: str
    title: str
    date_label: str
    duration_label: str
    audio_path: str
    downloaded_at: str


@dataclass(frozen=True)
class ExportedFiles:
    """Caminhos gerados na exportação de uma análise."""

    md_path: Path
    html_path: Path
    has_mindmap: bool


class HistoryStore:
    """Gerencia histórico persistente de downloads e análises em history.json."""

    def __init__(self, history_path: Path | None = None) -> None:
        self.history_path = (
            history_path if history_path is not None else get_history_file_path()
        )
        self.history_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.history_path.exists():
            self._write_raw({"downloads": {}, "analyses": {}})

    def _read_raw(self) -> dict[str, Any]:
        if not self.history_path.exists():
            return {"downloads": {}, "analyses": {}}
        try:
            data = json.loads(self.history_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {"downloads": {}, "analyses": {}}
        if not isinstance(data, dict):
            return {"downloads": {}, "analyses": {}}
        data.setdefault("downloads", {})
        data.setdefault("analyses", {})
        return data

    def _write_raw(self, data: dict[str, Any]) -> None:
        self.history_path.parent.mkdir(parents=True, exist_ok=True)
        self.history_path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    def is_plaud_downloaded(self, plaud_id: str) -> bool:
        """Retorna True se o ID da gravação do Plaud Web já foi registrado em history.json."""
        data = self._read_raw()
        return plaud_id in data["downloads"]

    def get_plaud_download(self, plaud_id: str) -> DownloadedPlaudRecord | None:
        """Retorna o registro de download de uma gravação do Plaud Web."""
        data = self._read_raw()
        entry = data["downloads"].get(plaud_id)
        if not isinstance(entry, dict):
            return None
        return DownloadedPlaudRecord(
            plaud_id=str(entry.get("plaud_id") or plaud_id),
            title=str(entry.get("title") or ""),
            date_label=str(entry.get("date_label") or ""),
            duration_label=str(entry.get("duration_label") or ""),
            audio_path=str(entry.get("audio_path") or ""),
            downloaded_at=str(entry.get("downloaded_at") or ""),
        )

    def record_plaud_download(
        self,
        *,
        plaud_id: str,
        title: str,
        date_label: str,
        duration_label: str,
        audio_path: Path,
        downloaded_at: datetime | None = None,
    ) -> None:
        """Registra uma gravação baixada do Plaud Web em history.json."""
        data = self._read_raw()
        rec = DownloadedPlaudRecord(
            plaud_id=plaud_id,
            title=title,
            date_label=date_label,
            duration_label=duration_label,
            audio_path=str(audio_path),
            downloaded_at=(downloaded_at or datetime.now()).isoformat(timespec="seconds"),
        )
        data["downloads"][plaud_id] = asdict(rec)
        self._write_raw(data)

    def is_processed(self, file_hash: str) -> bool:
        """Retorna True se o hash do áudio já foi analisado."""
        data = self._read_raw()
        return file_hash in data["analyses"]

    def get_record(self, file_hash: str) -> HistoryRecord | None:
        """Retorna o registro de análise para um hash, se existir."""
        data = self._read_raw()
        entry = data["analyses"].get(file_hash)
        if not isinstance(entry, dict):
            return None
        return HistoryRecord(
            file_hash=str(entry.get("file_hash") or file_hash),
            file_name=str(entry.get("file_name") or ""),
            source_path=str(entry.get("source_path") or ""),
            size_bytes=int(entry.get("size_bytes") or 0),
            processed_at=str(entry.get("processed_at") or ""),
            md_path=str(entry.get("md_path") or ""),
            html_path=str(entry.get("html_path") or ""),
            plaud_id=entry.get("plaud_id"),
        )

    def record_processed(
        self,
        *,
        file_hash: str,
        file_name: str,
        source_path: Path,
        size_bytes: int,
        md_path: Path,
        html_path: Path,
        plaud_id: str | None = None,
        processed_at: datetime | None = None,
    ) -> None:
        """Registra um áudio processado em history.json."""
        data = self._read_raw()
        rec = HistoryRecord(
            file_hash=file_hash,
            file_name=file_name,
            source_path=str(source_path),
            size_bytes=size_bytes,
            processed_at=(processed_at or datetime.now()).isoformat(timespec="seconds"),
            md_path=str(md_path),
            html_path=str(html_path),
            plaud_id=plaud_id,
        )
        data["analyses"][file_hash] = asdict(rec)
        self._write_raw(data)

    def list_records(self, limit: int = 50) -> list[HistoryRecord]:
        """Lista os registros de análise mais recentes."""
        data = self._read_raw()
        records: list[HistoryRecord] = []
        for file_hash, entry in data["analyses"].items():
            if not isinstance(entry, dict):
                continue
            records.append(
                HistoryRecord(
                    file_hash=str(entry.get("file_hash") or file_hash),
                    file_name=str(entry.get("file_name") or ""),
                    source_path=str(entry.get("source_path") or ""),
                    size_bytes=int(entry.get("size_bytes") or 0),
                    processed_at=str(entry.get("processed_at") or ""),
                    md_path=str(entry.get("md_path") or ""),
                    html_path=str(entry.get("html_path") or ""),
                    plaud_id=entry.get("plaud_id"),
                )
            )
        records.sort(key=lambda r: r.processed_at, reverse=True)
        return records[:limit]


def _sanitize_filename_stem(stem: str) -> str:
    cleaned = _UNSAFE_FILENAME_RE.sub("_", stem).strip("_")
    return cleaned or "audio"


def _sanitize_mindmap_label(text: str) -> str:
    """Remove caracteres que costumam quebrar o parser de mindmap do Mermaid."""
    cleaned = text.replace("**", "").replace("`", "")
    for ch in ("(", ")", "[", "]", "{", "}", ";", '"'):
        cleaned = cleaned.replace(ch, "")
    cleaned = cleaned.replace(":", " -")
    return " ".join(cleaned.split())


def sanitize_mermaid_mindmap(raw_mermaid: str) -> str:
    """Normaliza um bloco `mindmap` para evitar erros de sintaxe no Mermaid.js."""
    lines = [line.rstrip() for line in raw_mermaid.strip().splitlines() if line.strip()]
    if not lines:
        return "mindmap\n  root((Mapa Mental))"

    normalized: list[str] = []
    has_header = False

    for line in lines:
        stripped = line.strip()
        if stripped.lower() == "mindmap":
            if not has_header:
                normalized.append("mindmap")
                has_header = True
            continue

        if not has_header:
            normalized.append("mindmap")
            has_header = True

        indent_len = len(line) - len(line.lstrip(" "))
        indent = " " * max(2, indent_len)

        root_match = _ROOT_NODE_RE.match(line)
        if root_match:
            inner = _sanitize_mindmap_label(root_match.group(2)) or "Tema Central"
            normalized.append(f"{indent}root(({inner}))")
            continue

        clean_label = _sanitize_mindmap_label(stripped)
        if clean_label:
            normalized.append(f"{indent}{clean_label}")

    if len(normalized) == 1:
        normalized.append("  root((Mapa Mental))")
    return "\n".join(normalized)


def extract_mermaid_mindmap(markdown_text: str) -> str | None:
    """Extrai e higieniza o bloco Mermaid mindmap do Markdown."""
    matches = _MERMAID_BLOCK_RE.findall(markdown_text)
    if not matches:
        return None
    for block in matches:
        if "mindmap" in block.lower():
            return sanitize_mermaid_mindmap(block)
    return sanitize_mermaid_mindmap(matches[0])


def _extract_title(markdown_text: str, fallback_name: str) -> str:
    for line in markdown_text.splitlines():
        stripped = line.strip()
        if stripped.startswith("# "):
            return stripped[2:].strip()
    return fallback_name


def _build_mindmap_card_html(mindmap_code: str, download_stem: str) -> str:
    escaped_code = html.escape(mindmap_code)
    safe_svg_name = html.escape(f"{download_stem}_mindmap.svg")
    return f"""
<section class="mindmap-card" aria-label="Mapa Mental Interativo">
  <div class="mindmap-toolbar">
    <div class="mindmap-title">Mapa Mental Interativo</div>
    <div class="mindmap-actions">
      <button type="button" class="btn" id="zoom-out" title="Diminuir zoom">- Zoom</button>
      <button type="button" class="btn" id="zoom-reset" title="Resetar zoom">100%</button>
      <button type="button" class="btn" id="zoom-in" title="Aumentar zoom">+ Zoom</button>
      <button type="button" class="btn btn-primary" id="download-svg" data-filename="{safe_svg_name}">Baixar SVG</button>
    </div>
  </div>
  <div class="mindmap-viewport" id="mindmap-viewport">
    <div class="mindmap-stage" id="mindmap-stage">
      <pre class="mermaid" id="mermaid-diagram">{escaped_code}</pre>
    </div>
  </div>
  <details class="mindmap-source">
    <summary>Ver código Mermaid</summary>
    <pre><code>{escaped_code}</code></pre>
  </details>
</section>
"""


def render_standalone_html(
    markdown_text: str,
    *,
    source_name: str,
    generated_at: datetime,
    download_stem: str,
    engine_label: str = "Google Gemini Web",
) -> tuple[str, bool]:
    """Gera documento HTML autônomo estilizado com Mermaid.js CDN e botão para baixar SVG."""
    mindmap_code = extract_mermaid_mindmap(markdown_text)
    has_mindmap = mindmap_code is not None
    report_title = _extract_title(markdown_text, source_name)

    if mindmap_code is not None:
        body_markdown = _MERMAID_BLOCK_RE.sub(MERMAID_PLACEHOLDER, markdown_text, count=1)
    else:
        body_markdown = markdown_text

    body_html = md_lib.markdown(
        body_markdown,
        extensions=["tables", "fenced_code", "sane_lists"],
    )

    if mindmap_code is not None:
        card_html = _build_mindmap_card_html(mindmap_code, download_stem)
        if MERMAID_PLACEHOLDER in body_html:
            body_html = body_html.replace(f"<p>{MERMAID_PLACEHOLDER}</p>", card_html)
            body_html = body_html.replace(MERMAID_PLACEHOLDER, card_html)
        else:
            body_html = card_html + "\n" + body_html

    escaped_title = html.escape(report_title)
    escaped_source = html.escape(source_name)
    escaped_engine = html.escape(engine_label)
    formatted_date = html.escape(generated_at.strftime("%d/%m/%Y %H:%M:%S"))

    document = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{escaped_title} — Plaud CLI</title>
  <style>
    :root {{
      color-scheme: light dark;
      --bg: #f6f8fb;
      --surface: #ffffff;
      --surface-alt: #eef2f7;
      --text: #0f172a;
      --text-muted: #475569;
      --border: #dbe3ee;
      --accent: #2563eb;
      --accent-hover: #1d4ed8;
      --shadow: 0 10px 30px rgba(15, 23, 42, 0.08);
    }}

    @media (prefers-color-scheme: dark) {{
      :root {{
        --bg: #0b1120;
        --surface: #111827;
        --surface-alt: #1e293b;
        --text: #e2e8f0;
        --text-muted: #94a3b8;
        --border: #263244;
        --accent: #3b82f6;
        --accent-hover: #60a5fa;
        --shadow: 0 12px 32px rgba(0, 0, 0, 0.45);
      }}
    }}

    html[data-theme="light"] {{
      --bg: #f6f8fb;
      --surface: #ffffff;
      --surface-alt: #eef2f7;
      --text: #0f172a;
      --text-muted: #475569;
      --border: #dbe3ee;
      --accent: #2563eb;
      --accent-hover: #1d4ed8;
      --shadow: 0 10px 30px rgba(15, 23, 42, 0.08);
    }}

    html[data-theme="dark"] {{
      --bg: #0b1120;
      --surface: #111827;
      --surface-alt: #1e293b;
      --text: #e2e8f0;
      --text-muted: #94a3b8;
      --border: #263244;
      --accent: #3b82f6;
      --accent-hover: #60a5fa;
      --shadow: 0 12px 32px rgba(0, 0, 0, 0.45);
    }}

    * {{ box-sizing: border-box; }}

    body {{
      margin: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Inter, sans-serif;
      background: var(--bg);
      color: var(--text);
      line-height: 1.68;
    }}

    .container {{
      max-width: 1040px;
      margin: 0 auto;
      padding: 2rem 1.25rem 4rem;
    }}

    .topbar {{
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      align-items: center;
      gap: 1rem;
      margin-bottom: 1.5rem;
      padding: 0.9rem 1.2rem;
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 14px;
      box-shadow: var(--shadow);
    }}

    .meta-pills {{
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
      font-size: 0.85rem;
      color: var(--text-muted);
    }}

    .pill {{
      background: var(--surface-alt);
      border: 1px solid var(--border);
      padding: 0.25rem 0.65rem;
      border-radius: 999px;
    }}

    .report {{
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 18px;
      padding: 2rem;
      box-shadow: var(--shadow);
    }}

    .report h1 {{
      margin-top: 0;
      font-size: 1.9rem;
      line-height: 1.25;
      border-bottom: 2px solid var(--border);
      padding-bottom: 0.75rem;
    }}

    .report h2 {{
      margin-top: 2rem;
      font-size: 1.3rem;
      color: var(--accent);
    }}

    .report table {{
      width: 100%;
      border-collapse: collapse;
      margin: 1rem 0 1.5rem;
      overflow: hidden;
      border-radius: 10px;
      border: 1px solid var(--border);
    }}

    .report th, .report td {{
      padding: 0.75rem 0.9rem;
      border-bottom: 1px solid var(--border);
      text-align: left;
      vertical-align: top;
    }}

    .report th {{
      background: var(--surface-alt);
      font-weight: 600;
    }}

    .report blockquote {{
      margin: 1rem 0;
      padding: 0.75rem 1rem;
      border-left: 4px solid var(--accent);
      background: var(--surface-alt);
      border-radius: 0 10px 10px 0;
    }}

    .report pre {{
      background: var(--surface-alt);
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 0.9rem 1rem;
      overflow-x: auto;
    }}

    .mindmap-card {{
      margin: 1.25rem 0 2rem;
      border: 1px solid var(--border);
      border-radius: 14px;
      background: var(--surface-alt);
      overflow: hidden;
    }}

    .mindmap-toolbar {{
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      align-items: center;
      gap: 0.75rem;
      padding: 0.8rem 1rem;
      background: var(--surface);
      border-bottom: 1px solid var(--border);
    }}

    .mindmap-title {{
      font-weight: 600;
      font-size: 0.95rem;
    }}

    .mindmap-actions {{
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
    }}

    .btn {{
      appearance: none;
      border: 1px solid var(--border);
      background: var(--surface-alt);
      color: var(--text);
      border-radius: 8px;
      padding: 0.42rem 0.78rem;
      font-size: 0.85rem;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.15s ease, transform 0.1s ease;
    }}

    .btn:hover {{
      filter: brightness(1.06);
    }}

    .btn-primary {{
      background: var(--accent);
      border-color: var(--accent);
      color: #ffffff;
    }}

    .btn-primary:hover {{
      background: var(--accent-hover);
    }}

    .mindmap-viewport {{
      width: 100%;
      overflow: auto;
      padding: 1.25rem;
      min-height: 340px;
      display: flex;
      justify-content: center;
      align-items: flex-start;
    }}

    .mindmap-stage {{
      transform-origin: top center;
      transition: transform 0.15s ease;
    }}

    .mindmap-stage svg {{
      max-width: 100%;
      height: auto;
    }}

    .mindmap-source {{
      padding: 0.65rem 1rem;
      border-top: 1px solid var(--border);
      background: var(--surface);
      font-size: 0.85rem;
    }}

    .mindmap-source summary {{
      cursor: pointer;
      color: var(--text-muted);
    }}

    @media (max-width: 640px) {{
      .report {{ padding: 1.25rem; }}
    }}
  </style>
</head>
<body>
  <div class="container">
    <header class="topbar">
      <div class="meta-pills">
        <span class="pill"><strong>Arquivo:</strong> {escaped_source}</span>
        <span class="pill"><strong>Motor:</strong> {escaped_engine}</span>
        <span class="pill"><strong>Gerado em:</strong> {formatted_date}</span>
      </div>
      <button type="button" class="btn" id="toggle-theme">Alternar tema</button>
    </header>

    <main class="report">
      {body_html}
    </main>
  </div>

  <script type="module">
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    const themeToggle = document.getElementById('toggle-theme');
    if (themeToggle) {{
      themeToggle.addEventListener('click', () => {{
        const current = document.documentElement.getAttribute('data-theme');
        const next = current ? (current === 'dark' ? 'light' : 'dark') : (prefersDark ? 'light' : 'dark');
        document.documentElement.setAttribute('data-theme', next);
      }});
    }}

    try {{
      const mermaidModule = await import('https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs');
      const mermaid = mermaidModule.default;
      mermaid.initialize({{
        startOnLoad: false,
        theme: prefersDark ? 'dark' : 'default',
        securityLevel: 'loose'
      }});
      await mermaid.run({{ querySelector: '.mermaid' }});
    }} catch (err) {{
      console.warn('Falha ao carregar Mermaid.js CDN:', err);
    }}

    let zoomLevel = 1;
    const stage = document.getElementById('mindmap-stage');
    const applyZoom = () => {{
      if (stage) stage.style.transform = `scale(${{zoomLevel.toFixed(2)}})`;
    }};
    document.getElementById('zoom-in')?.addEventListener('click', () => {{
      zoomLevel = Math.min(2.5, zoomLevel + 0.15);
      applyZoom();
    }});
    document.getElementById('zoom-out')?.addEventListener('click', () => {{
      zoomLevel = Math.max(0.5, zoomLevel - 0.15);
      applyZoom();
    }});
    document.getElementById('zoom-reset')?.addEventListener('click', () => {{
      zoomLevel = 1;
      applyZoom();
    }});

    document.getElementById('download-svg')?.addEventListener('click', (event) => {{
      const svg = document.querySelector('#mermaid-diagram svg');
      if (!svg) {{
        alert('O diagrama SVG ainda não foi renderizado. Verifique sua conexão para carregar o Mermaid.js.');
        return;
      }}
      const serializer = new XMLSerializer();
      let source = serializer.serializeToString(svg);
      if (!source.match(/^<svg[^>]+xmlns="http:\\/\\/www\\.w3\\.org\\/2000\\/svg"/)) {{
        source = source.replace(/^<svg/, '<svg xmlns="http://www.w3.org/2000/svg"');
      }}
      const blob = new Blob(['<?xml version="1.0" encoding="UTF-8"?>\\n' + source], {{
        type: 'image/svg+xml;charset=utf-8'
      }});
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = event.currentTarget.getAttribute('data-filename') || 'mindmap.svg';
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
    }});
  </script>
</body>
</html>
"""
    return document, has_mindmap


def export_analysis(
    markdown_text: str,
    *,
    audio_path: Path,
    output_dir: Path,
    timestamp: datetime | None = None,
    engine_label: str = "Google Gemini Web",
) -> ExportedFiles:
    """Salva o relatório em .md e gera o arquivo .html autônomo com Mermaid.js."""
    now = timestamp or datetime.now()
    safe_stem = _sanitize_filename_stem(audio_path.stem)
    stamp = now.strftime("%Y%m%d_%H%M%S")
    base_name = f"{safe_stem}_{stamp}"

    resolved_output_dir = output_dir.expanduser()
    resolved_output_dir.mkdir(parents=True, exist_ok=True)

    md_path = resolved_output_dir / f"{base_name}.md"
    html_path = resolved_output_dir / f"{base_name}.html"

    md_path.write_text(markdown_text.rstrip() + "\n", encoding="utf-8")

    html_content, has_mindmap = render_standalone_html(
        markdown_text,
        source_name=audio_path.name,
        generated_at=now,
        download_stem=base_name,
        engine_label=engine_label,
    )
    html_path.write_text(html_content, encoding="utf-8")

    return ExportedFiles(md_path=md_path, html_path=html_path, has_mindmap=has_mindmap)


def open_in_browser(html_path: Path) -> bool:
    """Abre o relatório HTML no navegador padrão do sistema."""
    return bool(webbrowser.open(html_path.resolve().as_uri()))
