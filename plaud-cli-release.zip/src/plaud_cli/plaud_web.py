"""Automação Playwright para listar e baixar gravações do Plaud Web (app.plaud.ai)."""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from playwright.sync_api import BrowserContext, Page, Response
from playwright.sync_api import Error as PlaywrightError
from rich.console import Console

from plaud_cli.browser import open_authenticated_page, save_debug_screenshot
from plaud_cli.exporter import HistoryStore

_SAFE_NAME_RE = re.compile(r"[^\w\- ]+", re.UNICODE)


class PlaudWebError(RuntimeError):
    """Erro durante sincronização ou download no Plaud Web."""


@dataclass
class PlaudRecording:
    """Metadados de uma gravação listada no Plaud Web."""

    plaud_id: str
    title: str
    date_label: str
    duration_label: str
    download_url: str | None = None
    extension: str = ".mp3"
    already_downloaded: bool = False
    local_path: Path | None = None


def _format_duration_value(raw_val: Any) -> str:
    if raw_val is None:
        return "--:--"
    if isinstance(raw_val, str):
        stripped = raw_val.strip()
        if ":" in stripped:
            return stripped
        if stripped.isdigit():
            raw_val = int(stripped)
        else:
            return stripped or "--:--"
    if isinstance(raw_val, (int, float)):
        secs = int(raw_val / 1000) if raw_val > 86400 else int(raw_val)
        if secs <= 0:
            return "--:--"
        hours, rem = divmod(secs, 3600)
        mins, sec = divmod(rem, 60)
        if hours > 0:
            return f"{hours}:{mins:02d}:{sec:02d}"
        return f"{mins:02d}:{sec:02d}"
    return "--:--"


def _format_date_value(raw_val: Any) -> str:
    if raw_val is None:
        return "-"
    if isinstance(raw_val, (int, float)):
        ts = raw_val / 1000.0 if raw_val > 10_000_000_000 else float(raw_val)
        try:
            return datetime.fromtimestamp(ts).strftime("%d/%m/%Y %H:%M")
        except (OSError, ValueError):
            return str(raw_val)
    return str(raw_val).strip() or "-"


def parse_plaud_api_payload(payload: Any) -> list[PlaudRecording]:
    """Extrai gravações a partir de respostas JSON capturadas da API do Plaud Web."""
    items: list[dict[str, Any]] = []

    def _walk(node: Any) -> None:
        if isinstance(node, list):
            if node and all(isinstance(x, dict) for x in node):
                for entry in node:
                    if any(
                        k in entry
                        for k in ("id", "file_id", "record_id", "filename", "file_name")
                    ) and any(
                        k in entry
                        for k in (
                            "filename",
                            "file_name",
                            "title",
                            "name",
                            "duration",
                            "start_time",
                        )
                    ):
                        items.append(entry)
            for child in node:
                _walk(child)
        elif isinstance(node, dict):
            for val in node.values():
                if isinstance(val, (dict, list)):
                    _walk(val)

    _walk(payload)

    recordings: list[PlaudRecording] = []
    seen_ids: set[str] = set()
    for entry in items:
        rec_id = str(
            entry.get("id")
            or entry.get("file_id")
            or entry.get("record_id")
            or ""
        ).strip()
        if not rec_id or rec_id in seen_ids:
            continue
        seen_ids.add(rec_id)

        title = str(
            entry.get("filename")
            or entry.get("file_name")
            or entry.get("title")
            or entry.get("name")
            or f"Gravacao_{rec_id}"
        ).strip()
        date_label = _format_date_value(
            entry.get("start_time")
            or entry.get("created_at")
            or entry.get("create_time")
            or entry.get("date")
        )
        duration_label = _format_duration_value(
            entry.get("duration") or entry.get("duration_ms") or entry.get("time_len")
        )
        raw_url = (
            entry.get("download_url")
            or entry.get("audio_url")
            or entry.get("file_url")
            or entry.get("temp_url")
            or entry.get("url")
        )
        download_url = str(raw_url).strip() if raw_url else None
        ext = ".opus" if ".opus" in (title.lower() + str(download_url or "").lower()) else ".mp3"

        recordings.append(
            PlaudRecording(
                plaud_id=rec_id,
                title=title,
                date_label=date_label,
                duration_label=duration_label,
                download_url=download_url,
                extension=ext,
            )
        )
    return recordings


def _scrape_plaud_dom_recordings(page: Page) -> list[PlaudRecording]:
    """Fallback de extração via DOM quando o payload JSON da API não é interceptado."""
    raw_items = page.evaluate(
        """() => {
            const selectors = [
                '[data-file-id]',
                '[data-record-id]',
                '[class*="file-item"]',
                '[class*="record-item"]',
                '[role="row"]',
                'li[class*="item"]'
            ];
            const found = [];
            const seen = new Set();
            for (const sel of selectors) {
                for (const el of document.querySelectorAll(sel)) {
                    const text = (el.innerText || '').trim();
                    if (!text || text.length < 3) continue;
                    const id = el.getAttribute('data-file-id')
                        || el.getAttribute('data-record-id')
                        || el.getAttribute('data-id')
                        || text.slice(0, 80);
                    if (seen.has(id)) continue;
                    seen.add(id);
                    const lines = text.split('\\n').map(s => s.trim()).filter(Boolean);
                    found.push({
                        id,
                        title: lines[0] || id,
                        meta: lines.slice(1).join(' | ')
                    });
                }
            }
            return found;
        }"""
    )

    recordings: list[PlaudRecording] = []
    duration_re = re.compile(r"\b(?:\d{1,2}:)?\d{1,2}:\d{2}\b")
    date_re = re.compile(r"\b\d{2,4}[-/]\d{2}[-/]\d{2,4}(?:\s+\d{2}:\d{2})?\b")

    for idx, row in enumerate(raw_items or [], start=1):
        meta = str(row.get("meta") or "")
        dur_match = duration_re.search(meta)
        date_match = date_re.search(meta)
        recordings.append(
            PlaudRecording(
                plaud_id=str(row.get("id") or f"dom-{idx}"),
                title=str(row.get("title") or f"Gravacao {idx}"),
                date_label=date_match.group(0) if date_match else "-",
                duration_label=dur_match.group(0) if dur_match else "--:--",
            )
        )
    return recordings


def _mark_history_status(
    recordings: list[PlaudRecording],
    history: HistoryStore,
) -> list[PlaudRecording]:
    for rec in recordings:
        saved = history.get_plaud_download(rec.plaud_id)
        if saved is not None:
            rec.already_downloaded = True
            saved_path = Path(saved.audio_path)
            if saved_path.is_file():
                rec.local_path = saved_path
    return recordings


def _safe_audio_filename(title: str, plaud_id: str, extension: str) -> str:
    cleaned = _SAFE_NAME_RE.sub("_", title).strip(" _")
    cleaned = re.sub(r"\s+", "_", cleaned) or "gravacao"
    short_id = re.sub(r"[^\w\-]+", "", plaud_id)[:12] or "item"
    ext = extension if extension.startswith(".") else f".{extension}"
    return f"{cleaned[:60]}_{short_id}{ext}"


def _download_single_recording(
    page: Page,
    context: BrowserContext,
    recording: PlaudRecording,
    audios_dir: Path,
    history: HistoryStore,
) -> Path:
    """Baixa uma gravação do Plaud Web para audios_dir e registra em history.json."""
    if recording.already_downloaded and recording.local_path and recording.local_path.is_file():
        return recording.local_path

    audios_dir.mkdir(parents=True, exist_ok=True)
    target_path = audios_dir / _safe_audio_filename(
        recording.title, recording.plaud_id, recording.extension
    )

    # 1) Se já há URL assinada de download, baixa via request autenticado do contexto
    if recording.download_url:
        resp = context.request.get(recording.download_url, timeout=120000)
        if resp.ok:
            content = resp.body()
            if content:
                target_path.write_bytes(content)
                history.record_plaud_download(
                    plaud_id=recording.plaud_id,
                    title=recording.title,
                    date_label=recording.date_label,
                    duration_label=recording.duration_label,
                    audio_path=target_path,
                )
                return target_path

    # 2) Tenta acionar download pela UI do Plaud Web
    row_locator = page.locator(
        f"[data-file-id='{recording.plaud_id}'], [data-record-id='{recording.plaud_id}']"
    ).first
    try:
        if row_locator.is_visible(timeout=3000):
            row_locator.click()
        else:
            page.get_by_text(recording.title, exact=False).first.click(timeout=5000)
    except PlaywrightError as exc:
        shot = save_debug_screenshot(page)
        hint = f" Screenshot salvo em: {shot}" if shot else ""
        raise PlaudWebError(
            f"Não foi possível selecionar a gravação '{recording.title}' no Plaud Web: {exc}.{hint}"
        ) from exc

    download_selectors = (
        "button:has-text('Export')",
        "button:has-text('Download')",
        "button:has-text('Baixar')",
        "[aria-label*='download' i]",
        "[aria-label*='export' i]",
    )
    try:
        with page.expect_download(timeout=60000) as download_info:
            clicked = False
            for sel in download_selectors:
                loc = page.locator(sel).first
                if loc.is_visible(timeout=2000):
                    loc.click()
                    clicked = True
                    break
            if not clicked:
                raise PlaudWebError(
                    f"Botão de download/exportação não encontrado para '{recording.title}'."
                )
            # Se abrir menu de formato (MP3 / OPUS / Audio), clica em Audio / MP3
            for sub_sel in (
                "button:has-text('MP3')",
                "button:has-text('Audio')",
                "li:has-text('MP3')",
                "div[role='menuitem']:has-text('MP3')",
            ):
                sub_loc = page.locator(sub_sel).first
                try:
                    if sub_loc.is_visible(timeout=1500):
                        sub_loc.click()
                        break
                except Exception:
                    continue

        download = download_info.value
        suggested = download.suggested_filename
        if suggested and Path(suggested).suffix:
            target_path = audios_dir / _safe_audio_filename(
                recording.title, recording.plaud_id, Path(suggested).suffix
            )
        download.save_as(str(target_path))
    except PlaudWebError:
        shot = save_debug_screenshot(page)
        hint = f" Screenshot salvo em: {shot}" if shot else ""
        raise PlaudWebError(
            f"Falha ao localizar botão de download para '{recording.title}'.{hint}"
        )
    except PlaywrightError as exc:
        shot = save_debug_screenshot(page)
        hint = f" Screenshot salvo em: {shot}" if shot else ""
        raise PlaudWebError(
            f"Erro ao baixar '{recording.title}' do Plaud Web: {exc}.{hint}"
        ) from exc

    history.record_plaud_download(
        plaud_id=recording.plaud_id,
        title=recording.title,
        date_label=recording.date_label,
        duration_label=recording.duration_label,
        audio_path=target_path,
    )
    return target_path


def fetch_plaud_recordings(
    *,
    console: Console | None = None,
    history: HistoryStore | None = None,
) -> list[PlaudRecording]:
    """Abre https://app.plaud.ai em modo headless e retorna as gravações disponíveis."""
    store = history or HistoryStore()
    captured_payloads: list[Any] = []

    with open_authenticated_page("plaud", console=console) as (_context, page):
        def _on_response(response: Response) -> None:
            try:
                url = response.url.lower()
                if response.status == 200 and any(
                    k in url for k in ("/file/", "/record", "/list", "plaud")
                ):
                    ctype = (response.headers.get("content-type") or "").lower()
                    if "application/json" in ctype:
                        captured_payloads.append(response.json())
            except Exception:
                pass

        page.on("response", _on_response)
        try:
            page.reload(wait_until="networkidle", timeout=25000)
        except PlaywrightError:
            pass

        recordings: list[PlaudRecording] = []
        for payload in captured_payloads:
            recordings.extend(parse_plaud_api_payload(payload))

        if not recordings:
            recordings = _scrape_plaud_dom_recordings(page)

        if not recordings:
            shot = save_debug_screenshot(page)
            hint = f" Screenshot salvo em: {shot}" if shot else ""
            raise PlaudWebError(
                f"Nenhuma gravação encontrada no Plaud Web (app.plaud.ai).{hint}"
            )

        return _mark_history_status(recordings, store)


def download_plaud_recordings(
    recordings: list[PlaudRecording],
    *,
    audios_dir: Path,
    console: Console | None = None,
    history: HistoryStore | None = None,
) -> list[Path]:
    """Baixa as gravações selecionadas (ignorando as já registradas no history.json)."""
    store = history or HistoryStore()
    downloaded_paths: list[Path] = []

    to_fetch: list[PlaudRecording] = []
    for rec in recordings:
        saved = store.get_plaud_download(rec.plaud_id)
        if saved and Path(saved.audio_path).is_file():
            downloaded_paths.append(Path(saved.audio_path))
        elif not store.is_plaud_downloaded(rec.plaud_id):
            to_fetch.append(rec)

    if not to_fetch:
        return downloaded_paths

    with open_authenticated_page(
        "plaud",
        console=console,
        downloads_path=audios_dir,
    ) as (context, page):
        for rec in to_fetch:
            path = _download_single_recording(page, context, rec, audios_dir, store)
            downloaded_paths.append(path)

    return downloaded_paths

