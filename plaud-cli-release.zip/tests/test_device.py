"""Testes unitários para plaud_cli.device."""

import os
from pathlib import Path

from plaud_cli.device import (
    _detect_linux_devices,
    _detect_macos_devices,
    detect_external_devices,
    sanitize_dragged_path,
    scan_audio_files,
)


def test_sanitize_dragged_path_quotes_and_escapes(tmp_path: Path) -> None:
    assert sanitize_dragged_path("  '/tmp/reuniao 01.mp3'  ") == Path("/tmp/reuniao 01.mp3")
    assert sanitize_dragged_path('"/tmp/reuniao 02.wav"') == Path("/tmp/reuniao 02.wav")
    assert sanitize_dragged_path("& 'C:\\Gravacoes\\daily 01.mp3'") == Path(
        "C:\\Gravacoes\\daily 01.mp3"
    )
    assert sanitize_dragged_path("C:\\Users\\Alice\\My Audio\\note.mp3") == Path(
        "C:\\Users\\Alice\\My Audio\\note.mp3"
    )
    assert sanitize_dragged_path("reuniao\\ 01\\ \\(final\\).mp3") == Path(
        "reuniao 01 (final).mp3"
    )


def test_detect_macos_and_linux_volumes(tmp_path: Path) -> None:
    # Simula /Volumes no macOS
    volumes = tmp_path / "Volumes"
    (volumes / "Macintosh HD").mkdir(parents=True)
    plaud_vol = volumes / "PLAUD_NOTE"
    (plaud_vol / "RECORD").mkdir(parents=True)

    mac_devices = _detect_macos_devices(volumes_root=volumes)
    assert len(mac_devices) == 1
    assert mac_devices[0].name == "PLAUD_NOTE"
    assert mac_devices[0].is_plaud_likely is True
    assert mac_devices[0].scan_paths == (plaud_vol / "RECORD",)

    # Simula /media/$USER e /mnt no Linux
    linux_media = tmp_path / "media" / "alice"
    (linux_media / "USB_DRIVE" / "VOICE").mkdir(parents=True)
    linux_mnt = tmp_path / "mnt"
    linux_mnt.mkdir(parents=True)

    linux_devices = _detect_linux_devices(
        user="alice",
        media_bases=(linux_media, linux_mnt),
    )
    assert len(linux_devices) == 1
    assert linux_devices[0].name == "USB_DRIVE"
    assert linux_devices[0].is_plaud_likely is True


def test_detect_external_devices_includes_extra_sync_dir(tmp_path: Path) -> None:
    sync_dir = tmp_path / "MinhaPastaPlaud"
    (sync_dir / "RECORD").mkdir(parents=True)
    devices = detect_external_devices(extra_sync_dir=sync_dir, system_name="UnknownOS")
    assert len(devices) == 1
    assert devices[0].kind == "local"
    assert devices[0].is_plaud_likely is True


def test_scan_audio_files_orders_by_mtime_and_marks_processed(tmp_path: Path) -> None:
    older = tmp_path / "old.mp3"
    newer = tmp_path / "new.opus"
    ignored = tmp_path / "notes.txt"

    older.write_bytes(b"old-audio-bytes")
    newer.write_bytes(b"new-audio-bytes")
    ignored.write_text("not audio", encoding="utf-8")

    os.utime(older, (1_700_000_000, 1_700_000_000))
    os.utime(newer, (1_700_001_000, 1_700_001_000))

    first_pass = scan_audio_files([tmp_path])
    assert [f.name for f in first_pass] == ["new.opus", "old.mp3"]
    assert all(not f.processed for f in first_pass)

    known_hashes = {first_pass[1].file_hash}
    second_pass = scan_audio_files([tmp_path], is_processed_fn=lambda h: h in known_hashes)
    assert second_pass[0].processed is False
    assert second_pass[1].processed is True

