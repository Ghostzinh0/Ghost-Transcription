@echo off
chcp 65001 >nul
setlocal EnableExtensions

cd /d "%~dp0"

echo ==================================================
echo   Instalador Automatico - plaud-cli (Windows)
echo ==================================================
echo.

where python >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Python nao foi encontrado no PATH do sistema.
    echo.
    echo Instale o Python 3.10 ou superior pelo site oficial:
    echo   https://www.python.org/downloads/
    echo.
    echo IMPORTANTE: Durante a instalacao, marque a opcao
    echo "Add python.exe to PATH" e execute este script novamente.
    echo.
    pause
    exit /b 1
)

python -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1
if errorlevel 1 (
    echo [ERRO] E necessario Python 3.10 ou superior.
    echo Baixe a versao mais recente em:
    echo   https://www.python.org/downloads/
    echo.
    pause
    exit /b 1
)

echo [1/5] Verificando ambiente virtual (.venv)...
if not exist ".venv\Scripts\python.exe" (
    python -m venv .venv
    if errorlevel 1 (
        echo [ERRO] Falha ao criar o ambiente virtual .venv.
        pause
        exit /b 1
    )
) else (
    echo Ambiente virtual .venv ja existe. Reutilizando...
)

echo.
echo [2/5] Ativando .venv e atualizando o pip...
call ".venv\Scripts\activate.bat"
if errorlevel 1 (
    echo [ERRO] Nao foi possivel ativar o ambiente virtual .venv.
    pause
    exit /b 1
)

python -m pip install --upgrade pip
if errorlevel 1 (
    echo [ERRO] Falha ao atualizar o pip.
    pause
    exit /b 1
)

echo.
echo [3/5] Instalando o plaud-cli em modo editavel...
pip install -e .
if errorlevel 1 (
    echo [ERRO] Falha ao instalar o pacote plaud-cli.
    pause
    exit /b 1
)

echo.
echo [4/5] Instalando navegador Chromium do Playwright...
playwright install chromium
if errorlevel 1 (
    echo [ERRO] Falha ao instalar o Chromium via Playwright.
    pause
    exit /b 1
)

echo.
echo [5/5] Configurando comando global 'plaud'...
set "LOCAL_BIN=%USERPROFILE%\.local\bin"
if not exist "%LOCAL_BIN%" (
    mkdir "%LOCAL_BIN%"
)

(
    echo @echo off
    echo "%~dp0.venv\Scripts\plaud.exe" %%*
) > "%LOCAL_BIN%\plaud.cmd"

if errorlevel 1 (
    echo [ERRO] Nao foi possivel criar "%LOCAL_BIN%\plaud.cmd".
    pause
    exit /b 1
)

set "USER_PATH="
for /f "tokens=1,2,*" %%A in ('reg query "HKCU\Environment" /v Path 2^>nul') do (
    if /i "%%A"=="Path" set "USER_PATH=%%C"
)

setlocal EnableDelayedExpansion
set "NEED_ADD=1"
if defined USER_PATH (
    echo ;!USER_PATH!; | findstr /i /c:";!LOCAL_BIN!;" >nul && set "NEED_ADD=0"
)
if "!NEED_ADD!"=="1" (
    if defined USER_PATH (
        setx PATH "!USER_PATH!;!LOCAL_BIN!" >nul
    ) else (
        setx PATH "!LOCAL_BIN!" >nul
    )
    if errorlevel 1 (
        echo [AVISO] Nao foi possivel atualizar o PATH automaticamente via setx.
        echo Adicione manualmente ao PATH do usuario: !LOCAL_BIN!
    ) else (
        echo Pasta adicionada ao PATH do usuario: !LOCAL_BIN!
    )
) else (
    echo Pasta !LOCAL_BIN! ja esta no PATH do usuario.
)
endlocal

echo.
echo ==================================================
echo   Instalacao concluida com sucesso!
echo ==================================================
echo.
echo Wrapper criado em: %LOCAL_BIN%\plaud.cmd
echo Abra um NOVO terminal (Prompt de Comando, PowerShell ou Windows Terminal)
echo e digite:
echo.
echo   plaud
echo.
pause
