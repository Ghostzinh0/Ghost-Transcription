"""Gerenciador de sessões persistentes Playwright com fluxo híbrido headless/visível."""

from __future__ import annotations

import platform
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import TypeVar

import psutil
from playwright.sync_api import BrowserContext, Page, Playwright, sync_playwright
from playwright.sync_api import Error as PlaywrightError
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt

from plaud_cli.config import (
    get_debug_html_path,
    get_debug_screenshot_path,
    get_profile_dir,
)

T = TypeVar("T")

SERVICE_URLS: dict[str, str] = {
    "gemini": "https://gemini.google.com/app",
    "plaud": "https://app.plaud.ai",
}

VIEWPORT_SIZE = {"width": 1920, "height": 1080}

_STEALTH_INIT_SCRIPT = """
Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
"""


class BrowserSessionError(RuntimeError):
    """Erro ao inicializar ou manter sessão Playwright."""


def get_realistic_user_agent(system_name: str | None = None) -> str:
    """Retorna um User-Agent desktop realista alinhado ao sistema operacional."""
    current_os = system_name or platform.system()
    if current_os == "Darwin":
        return (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/131.0.0.0 Safari/537.36"
        )
    if current_os == "Linux":
        return (
            "Mozilla/5.0 (X11; Linux x86_64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/131.0.0.0 Safari/537.36"
        )
    return (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/131.0.0.0 Safari/537.36"
    )


def find_profile_lock_pids(profile_dir: Path) -> list[int]:
    """Verifica via psutil se algum processo Chrome/Chromium já está usando o perfil."""
    target = str(profile_dir.resolve()).lower()
    pids: list[int] = []
    for proc in psutil.process_iter(["pid", "name", "cmdline"]):
        try:
            name = (proc.info.get("name") or "").lower()
            if "chrome" not in name and "chromium" not in name:
                continue
            cmdline = " ".join(proc.info.get("cmdline") or []).lower()
            if target in cmdline:
                pids.append(int(proc.info["pid"]))
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    return pids


def launch_persistent_browser(
    pw: Playwright,
    profile_dir: Path,
    *,
    headless: bool,
    downloads_path: Path | None = None,
) -> BrowserContext:
    """Inicia contexto persistente usando channel='chrome' com fallback para 'chromium'."""
    profile_dir.mkdir(parents=True, exist_ok=True)
    lock_pids = find_profile_lock_pids(profile_dir)
    if lock_pids:
        raise BrowserSessionError(
            f"O perfil do navegador em {profile_dir} já está em uso pelos processos PID {lock_pids}. "
            "Feche a janela aberta antes de continuar."
        )

    launch_kwargs: dict = {
        "user_data_dir": str(profile_dir),
        "headless": headless,
        "viewport": VIEWPORT_SIZE,
        "user_agent": get_realistic_user_agent(),
        "accept_downloads": True,
        "args": [
            "--disable-blink-features=AutomationControlled",
            "--no-first-run",
            "--no-default-browser-check",
        ],
        "ignore_default_args": ["--enable-automation"],
    }
    if downloads_path is not None:
        downloads_path.mkdir(parents=True, exist_ok=True)
        launch_kwargs["downloads_path"] = str(downloads_path)

    try:
        context = pw.chromium.launch_persistent_context(channel="chrome", **launch_kwargs)
    except PlaywrightError:
        try:
            context = pw.chromium.launch_persistent_context(**launch_kwargs)
        except PlaywrightError as exc:
            raise BrowserSessionError(
                "Não foi possível iniciar o navegador via Playwright. "
                "Execute `playwright install chromium` e tente novamente.\n"
                f"Detalhe: {exc}"
            ) from exc

    context.add_init_script(_STEALTH_INIT_SCRIPT)
    return context


def _get_or_create_page(context: BrowserContext) -> Page:
    if context.pages:
        return context.pages[0]
    return context.new_page()


def save_debug_screenshot(
    page: Page,
    destination: Path | None = None,
) -> Path | None:
    """Salva screenshot de depuração em ~/.plaud_cli/debug_error.png."""
    target = destination if destination is not None else get_debug_screenshot_path()
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        page.screenshot(path=str(target), full_page=False)
        return target
    except Exception:
        return None


def save_debug_html(
    page: Page,
    destination: Path | None = None,
) -> Path | None:
    """Salva o HTML completo da página em ~/.plaud_cli/debug_error.html."""
    target = destination if destination is not None else get_debug_html_path()
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(page.content(), encoding="utf-8")
        return target
    except Exception:
        return None


def is_gemini_login_required(page: Page) -> bool:
    """Detecta se a página do Gemini redirecionou para login Google."""
    url = (page.url or "").lower()
    if any(
        token in url
        for token in (
            "accounts.google.com",
            "servicelogin",
            "/signin",
            "consent.google.com",
        )
    ):
        return True

    # Verifica ausência da caixa de prompt e presença de CTA de login
    prompt_selectors = (
        "rich-textarea div[contenteditable='true']",
        "div[contenteditable='true'][role='textbox']",
        "textarea",
    )
    for sel in prompt_selectors:
        try:
            if page.locator(sel).first.is_visible(timeout=1500):
                return False
        except Exception:
            continue

    login_selectors = (
        "a[href*='accounts.google.com']",
        "button:has-text('Fazer login')",
        "button:has-text('Sign in')",
        "a:has-text('Fazer login')",
        "a:has-text('Sign in')",
    )
    for sel in login_selectors:
        try:
            if page.locator(sel).first.is_visible(timeout=800):
                return True
        except Exception:
            continue

    return "gemini.google.com" not in url


def is_plaud_login_required(page: Page) -> bool:
    """Detecta se o Plaud Web exibiu tela de login ou autenticação."""
    url = (page.url or "").lower()
    if any(token in url for token in ("/login", "/signin", "/auth", "accounts.google.com")):
        return True

    login_selectors = (
        "input[type='password']",
        "button:has-text('Log in')",
        "button:has-text('Sign in')",
        "button:has-text('Entrar')",
        "button:has-text('Continue with Google')",
        "button:has-text('Continuar com o Google')",
    )
    for sel in login_selectors:
        try:
            if page.locator(sel).first.is_visible(timeout=1200):
                return True
        except Exception:
            continue

    return False


def _prompt_user_login_completion(
    console: Console,
    service_label: str,
    target_url: str,
) -> None:
    console.print(
        Panel(
            f"[yellow]Sessão não autenticada detectada para {service_label}.[/yellow]\n\n"
            f"Uma janela visível do navegador foi aberta em:\n[cyan]{target_url}[/cyan]\n\n"
            "1. Conclua o login normalmente na janela do navegador.\n"
            "2. Volte a este terminal e pressione [bold green]Enter[/bold green] para continuar "
            "em segundo plano (headless).",
            title=f"[bold cyan]Login necessário — {service_label}[/bold cyan]",
            border_style="yellow",
        )
    )
    Prompt.ask("Pressione Enter após concluir o login no navegador", default="")


def interactive_login(
    service: str,
    *,
    console: Console | None = None,
    profile_dir: Path | None = None,
    wait_fn: Callable[[], None] | None = None,
) -> Path:
    """Abre janela visível (headless=False) para autenticar ou trocar conta."""
    normalized = service.strip().lower()
    if normalized not in SERVICE_URLS:
        raise BrowserSessionError(
            f"Serviço inválido '{service}'. Use 'gemini' ou 'plaud'."
        )

    target_url = SERVICE_URLS[normalized]
    resolved_profile = profile_dir or get_profile_dir(normalized)
    out = console or Console()
    label = "Google Gemini" if normalized == "gemini" else "Plaud Web"

    with sync_playwright() as pw:
        context = launch_persistent_browser(
            pw,
            resolved_profile,
            headless=False,
        )
        try:
            page = _get_or_create_page(context)
            page.goto(target_url, wait_until="domcontentloaded", timeout=60000)

            if wait_fn is not None:
                wait_fn()
            else:
                out.print(
                    Panel(
                        f"Navegador aberto em [cyan]{target_url}[/cyan].\n"
                        f"Perfil salvo em: [dim]{resolved_profile}[/dim]\n\n"
                        "Faça login ou troque de conta na janela aberta e pressione "
                        "[bold green]Enter[/bold green] aqui para salvar e fechar.",
                        title=f"[bold cyan]Gerenciar Login — {label}[/bold cyan]",
                        border_style="cyan",
                    )
                )
                Prompt.ask("Pressione Enter após finalizar o login", default="")
        finally:
            context.close()

    return resolved_profile


@contextmanager
def open_authenticated_page(
    service: str,
    *,
    console: Console | None = None,
    profile_dir: Path | None = None,
    downloads_path: Path | None = None,
    wait_for_login_fn: Callable[[], None] | None = None,
) -> Iterator[tuple[BrowserContext, Page]]:
    """
    Abre sessão persistente em modo headless=True; se detectar tela de login,
    abre janela visível para autenticação, aguarda Enter e retoma em headless=True.
    """
    normalized = service.strip().lower()
    if normalized not in SERVICE_URLS:
        raise BrowserSessionError(
            f"Serviço inválido '{service}'. Use 'gemini' ou 'plaud'."
        )

    target_url = SERVICE_URLS[normalized]
    resolved_profile = profile_dir or get_profile_dir(normalized)
    out = console or Console()
    label = "Google Gemini" if normalized == "gemini" else "Plaud Web"
    needs_login = (
        is_gemini_login_required if normalized == "gemini" else is_plaud_login_required
    )

    with sync_playwright() as pw:
        # 1) Sempre inicia tentando em segundo plano (headless=True)
        context = launch_persistent_browser(
            pw,
            resolved_profile,
            headless=True,
            downloads_path=downloads_path,
        )
        try:
            page = _get_or_create_page(context)
            page.goto(target_url, wait_until="domcontentloaded", timeout=60000)
            try:
                page.wait_for_load_state("networkidle", timeout=10000)
            except PlaywrightError:
                pass

            if needs_login(page):
                # 2) Fecha headless, abre visível para login único e retoma em headless=True
                context.close()

                visible_ctx = launch_persistent_browser(
                    pw,
                    resolved_profile,
                    headless=False,
                    downloads_path=downloads_path,
                )
                try:
                    vis_page = _get_or_create_page(visible_ctx)
                    vis_page.goto(target_url, wait_until="domcontentloaded", timeout=60000)
                    if wait_for_login_fn is not None:
                        wait_for_login_fn()
                    else:
                        _prompt_user_login_completion(out, label, target_url)
                finally:
                    visible_ctx.close()

                # 3) Retoma 100% em segundo plano (headless=True)
                context = launch_persistent_browser(
                    pw,
                    resolved_profile,
                    headless=True,
                    downloads_path=downloads_path,
                )
                page = _get_or_create_page(context)
                page.goto(target_url, wait_until="domcontentloaded", timeout=60000)
                try:
                    page.wait_for_load_state("networkidle", timeout=10000)
                except PlaywrightError:
                    pass

                if needs_login(page):
                    shot = save_debug_screenshot(page)
                    hint = f" Screenshot salvo em: {shot}" if shot else ""
                    raise BrowserSessionError(
                        f"O login em {label} não pôde ser confirmado em modo headless.{hint}"
                    )

            yield context, page
        finally:
            try:
                context.close()
            except Exception:
                pass

