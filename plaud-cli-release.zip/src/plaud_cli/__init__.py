"""plaud-cli: CLI multiplataforma via Playwright (Plaud Web + Gemini Web)."""

__all__ = ["__version__", "APP_NAME"]

__version__ = "0.2.0"
APP_NAME = "plaud-cli"
