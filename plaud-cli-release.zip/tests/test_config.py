"""Testes unitários para plaud_cli.config."""

from pathlib import Path

import pytest

from plaud_cli.config import (
    get_debug_html_path,
    get_debug_screenshot_path,
    get_profile_dir,
    load_config,
    update_stored_config,
)


def test_load_config_defaults_and_updates(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    cfg_dir = tmp_path / "cfg"
    monkeypatch.delenv("PLAUD_CLI_AUDIOS_DIR", raising=False)
    monkeypatch.delenv("PLAUD_CLI_OUTPUT_DIR", raising=False)

    loaded = load_config(config_dir=cfg_dir)
    assert loaded.audios_dir.name == "audios"
    assert loaded.output_dir.name == "resultados"

    custom_audios = tmp_path / "meus_audios"
    custom_out = tmp_path / "meus_resultados"
    update_stored_config(
        audios_dir=custom_audios,
        output_dir=custom_out,
        config_dir=cfg_dir,
    )

    reloaded = load_config(config_dir=cfg_dir)
    assert reloaded.audios_dir == custom_audios
    assert reloaded.output_dir == custom_out


def test_profile_dirs_and_debug_screenshot(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr("plaud_cli.config.get_data_dir", lambda: tmp_path / "data")
    gemini_dir = get_profile_dir("gemini")
    plaud_dir = get_profile_dir("plaud")
    assert gemini_dir.exists()
    assert plaud_dir.exists()
    assert gemini_dir.parent.name == "profiles"

    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    shot = get_debug_screenshot_path()
    assert shot == tmp_path / ".plaud_cli" / "debug_error.png"
    assert shot.parent.exists()
    html_dump = get_debug_html_path()
    assert html_dump == tmp_path / ".plaud_cli" / "debug_error.html"
    assert html_dump.parent.exists()
