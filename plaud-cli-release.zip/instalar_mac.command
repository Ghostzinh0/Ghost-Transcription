#!/bin/bash
set -e
cd "$(dirname "$0")"

export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

echo "=================================================="
echo "  Instalador Automático - plaud-cli (macOS)"
echo "=================================================="
echo ""

if ! command -v python3 >/dev/null 2>&1; then
    echo "[ERRO] python3 não foi encontrado no PATH."
    echo ""
    echo "Instale o Python 3.10+ usando Homebrew:"
    echo "  brew install python"
    echo ""
    echo "Ou baixe o instalador oficial em:"
    echo "  https://www.python.org/downloads/macos/"
    echo ""
    read -p "Pressione Enter para fechar..."
    exit 1
fi

if ! python3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)"; then
    echo "[ERRO] É necessário Python 3.10 ou superior."
    echo "Versão encontrada: $(python3 --version)"
    echo "Atualize com 'brew install python' ou via https://www.python.org/downloads/macos/"
    echo ""
    read -p "Pressione Enter para fechar..."
    exit 1
fi

echo "Python detectado: $(python3 --version) ($(command -v python3))"
echo ""

echo "[1/5] Criando ambiente virtual (.venv)..."
if [ ! -d ".venv" ]; then
    python3 -m venv .venv
else
    echo "Ambiente virtual .venv já existe. Reutilizando..."
fi

echo ""
echo "[2/5] Ativando .venv e atualizando pip..."
# shellcheck disable=SC1091
source .venv/bin/activate
pip install --upgrade pip

echo ""
echo "[3/5] Instalando o plaud-cli em modo editável..."
pip install -e .

echo ""
echo "[4/5] Instalando navegador Chromium do Playwright..."
playwright install chromium

echo ""
echo "[5/5] Registrando comando global 'plaud' no macOS..."
TARGET_BIN="$(pwd)/.venv/bin/plaud"
LINK_DIR="/usr/local/bin"
LINK_PATH="${LINK_DIR}/plaud"

if [ -d "$LINK_DIR" ] && [ -w "$LINK_DIR" ]; then
    ln -sf "$TARGET_BIN" "$LINK_PATH"
else
    echo ""
    echo "Será solicitada a senha do administrador do Mac para liberar o comando 'plaud' globalmente em ${LINK_PATH}:"
    sudo mkdir -p "$LINK_DIR" && sudo ln -sf "$TARGET_BIN" "$LINK_PATH"
fi

ZSHRC="$HOME/.zshrc"
if [ ! -f "$ZSHRC" ] || ! grep -F -q "/usr/local/bin" "$ZSHRC"; then
    echo "" >> "$ZSHRC"
    echo 'export PATH="/usr/local/bin:$PATH"' >> "$ZSHRC"
    echo "Adicionado /usr/local/bin ao PATH em ~/.zshrc"
fi

echo ""
echo "=================================================="
echo "  Instalação concluída com sucesso!"
echo "=================================================="
echo "Link global: $LINK_PATH -> $TARGET_BIN"
echo ""
read -p "Instalacao concluida! Pressione Enter para fechar e abra um novo Terminal digitando: plaud"
